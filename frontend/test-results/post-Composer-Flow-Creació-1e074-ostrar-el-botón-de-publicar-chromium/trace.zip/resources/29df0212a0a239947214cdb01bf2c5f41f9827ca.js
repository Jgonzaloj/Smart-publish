import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/AuthLayout.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=03b8b458";
import { Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=03b8b458";
var _jsxFileName = "C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AuthLayout.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03b8b458";
export const AuthLayout = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen flex w-full bg-slate-50 dark:bg-slate-900",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "w-full lg:w-1/2 flex flex-col justify-center items-center p-8 lg:p-24 bg-white dark:bg-[#1e293b]",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "w-full max-w-md",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 mb-12",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-xl bg-brand-500 flex items-center justify-center text-white shadow-lg shadow-brand-500/20",
						children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 24 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 13,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-600 to-brand-400",
						children: "Smart Publish"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 11,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "hidden lg:flex w-1/2 text-white p-12 flex-col justify-between relative overflow-hidden",
			style: {
				backgroundImage: "url(/auth-bg.png)",
				backgroundSize: "cover",
				backgroundPosition: "center"
			},
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-slate-900/40 mix-blend-overlay" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "relative z-10" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative z-10 max-w-lg mb-20",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-4xl lg:text-5xl font-bold leading-tight mb-6",
						children: "Gestiona tus redes sociales con Inteligencia Artificial."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-brand-100 text-lg",
						children: "Únete a cientos de agencias y creadores que programan, generan y analizan su contenido en piloto automático."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative z-10 text-sm text-brand-200",
					children: [
						"© ",
						new Date().getFullYear(),
						" Smart Publish. Todos los derechos reservados."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
};
_c = AuthLayout;
var _c;
$RefreshReg$(_c, "AuthLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/AuthLayout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AuthLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AuthLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AuthLayout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZ0JBQWdCOzs7QUFFekIsT0FBTyxNQUFNLG1CQUFtQjtDQUM5QixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FHRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7S0FDbEI7Ozs7ZUFDTCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZ0c7S0FFMUc7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxRQUFELENBQVM7Ozs7WUFDTjs7Ozs7O0VBQ0Y7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQ0UsV0FBVTtHQUNWLE9BQU87SUFBRSxpQkFBaUI7SUFBcUIsZ0JBQWdCO0lBQVMsb0JBQW9CO0dBQVM7YUFGdkc7SUFJRSx3QkFBQyxPQUFELEVBQUssV0FBVSxxREFBMEQ7Ozs7O0lBQ3pFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHNGQUEyRjs7Ozs7SUFFMUcsd0JBQUMsT0FBRCxFQUFLLFdBQVUsZ0JBRVY7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvRDtLQUU5RDs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5QjtLQUVuQzs7OzthQUNBOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQXNEO01BQ2pELElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtNQUFFO0tBQ3pCOzs7Ozs7R0FDRjs7Ozs7VUFFRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXV0aExheW91dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgT3V0bGV0IH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBTcGFya2xlcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBBdXRoTGF5b3V0ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggdy1mdWxsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTAwXCI+XG4gICAgICBcbiAgICAgIHsvKiBDb2x1bW5hIEl6cXVpZXJkYTogRm9ybXVsYXJpbyAoQXV0aCkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBsZzp3LTEvMiBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBwLTggbGc6cC0yNCBiZy13aGl0ZSBkYXJrOmJnLVsjMWUyOTNiXVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctYnJhbmQtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LWxnIHNoYWRvdy1icmFuZC01MDAvMjBcIj5cbiAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezI0fSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJyYW5kLTYwMCB0by1icmFuZC00MDBcIj5cbiAgICAgICAgICAgICAgU21hcnQgUHVibGlzaFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxPdXRsZXQgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENvbHVtbmEgRGVyZWNoYTogSW1hZ2VuL0RlY29yYWNpw7NuICovfVxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmZsZXggdy0xLzIgdGV4dC13aGl0ZSBwLTEyIGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIlxuICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kSW1hZ2U6ICd1cmwoL2F1dGgtYmcucG5nKScsIGJhY2tncm91bmRTaXplOiAnY292ZXInLCBiYWNrZ3JvdW5kUG9zaXRpb246ICdjZW50ZXInIH19XG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNDAgbWl4LWJsZW5kLW92ZXJsYXlcIj48L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWdyYWRpZW50LXRvLXQgZnJvbS1zbGF0ZS05MDAvOTAgdmlhLXNsYXRlLTkwMC80MCB0by10cmFuc3BhcmVudFwiPjwvZGl2PlxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgey8qIEVzcGFjaW8gcmVzZXJ2YWRvIHBhcmEgdGV4dG8gc3VwZXJpb3IgKi99XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBtYXgtdy1sZyBtYi0yMFwiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBsZzp0ZXh0LTV4bCBmb250LWJvbGQgbGVhZGluZy10aWdodCBtYi02XCI+XG4gICAgICAgICAgICBHZXN0aW9uYSB0dXMgcmVkZXMgc29jaWFsZXMgY29uIEludGVsaWdlbmNpYSBBcnRpZmljaWFsLlxuICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1icmFuZC0xMDAgdGV4dC1sZ1wiPlxuICAgICAgICAgICAgw5puZXRlIGEgY2llbnRvcyBkZSBhZ2VuY2lhcyB5IGNyZWFkb3JlcyBxdWUgcHJvZ3JhbWFuLCBnZW5lcmFuIHkgYW5hbGl6YW4gc3UgY29udGVuaWRvIGVuIHBpbG90byBhdXRvbcOhdGljby5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIHRleHQtc20gdGV4dC1icmFuZC0yMDBcIj5cbiAgICAgICAgICDCqSB7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSBTbWFydCBQdWJsaXNoLiBUb2RvcyBsb3MgZGVyZWNob3MgcmVzZXJ2YWRvcy5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==