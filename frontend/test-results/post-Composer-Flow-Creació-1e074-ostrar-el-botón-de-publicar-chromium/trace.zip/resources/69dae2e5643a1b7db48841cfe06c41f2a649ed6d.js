import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/AuthContext.tsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03b8b458";
import { api } from "/src/lib/api.ts";
var _jsxFileName = "C:/Users/Admin/Desktop/smart-publish/frontend/src/contexts/AuthContext.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03b8b458";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(undefined);
_c = AuthContext;
export const AuthProvider = ({ children }) => {
	_s();
	const [user, setUser] = useState(null);
	const [token, setToken] = useState(null);
	const [isLoading, setIsLoading] = useState(true);
	useEffect(() => {
		// Check for saved auth state on mount
		const savedToken = localStorage.getItem("auth_token");
		const savedUser = localStorage.getItem("auth_user");
		if (savedToken && savedUser) {
			try {
				setToken(savedToken);
				setUser(JSON.parse(savedUser));
				api.defaults.headers.common["Authorization"] = `Bearer ${savedToken}`;
				// Automatically inject workspaceId to all requests using axios interceptor
				api.defaults.headers.common["x-workspace-id"] = JSON.parse(savedUser).workspace_id;
			} catch (e) {
				logout();
			}
		}
		setIsLoading(false);
	}, []);
	const login = (newToken, newUser, workspaceId) => {
		const fullUser = {
			...newUser,
			workspace_id: workspaceId
		};
		setToken(newToken);
		setUser(fullUser);
		localStorage.setItem("auth_token", newToken);
		localStorage.setItem("auth_user", JSON.stringify(fullUser));
		api.defaults.headers.common["Authorization"] = `Bearer ${newToken}`;
		api.defaults.headers.common["x-workspace-id"] = workspaceId;
	};
	const logout = () => {
		setToken(null);
		setUser(null);
		localStorage.removeItem("auth_token");
		localStorage.removeItem("auth_user");
		delete api.defaults.headers.common["Authorization"];
		delete api.defaults.headers.common["x-workspace-id"];
	};
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value: {
			user,
			token,
			isAuthenticated: !!token,
			login,
			logout,
			isLoading
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
};
_s(AuthProvider, "p3XmKa90rKsr8c24bjKRsN7oloI=");
_c2 = AuthProvider;
export const useAuth = () => {
	_s2();
	const context = useContext(AuthContext);
	if (context === undefined) {
		throw new Error("useAuth must be used within an AuthProvider");
	}
	return context;
};
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/contexts/AuthContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Admin/Desktop/smart-publish/frontend/src/contexts/AuthContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Admin/Desktop/smart-publish/frontend/src/contexts/AuthContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Admin/Desktop/smart-publish/frontend/src/contexts/AuthContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsWUFBWSxVQUFVLGlCQUFpQjtBQUN0RSxTQUFTLFdBQVc7Ozs7QUFrQnBCLE1BQU0sY0FBYyxjQUEyQyxTQUFTOztBQUV4RSxPQUFPLE1BQU0sZ0JBQXlELEVBQUUsZUFBZTs7Q0FDckYsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFzQixJQUFJO0NBQ2xELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUN0RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxJQUFJO0NBRS9DLGdCQUFnQjs7RUFFZCxNQUFNLGFBQWEsYUFBYSxRQUFRLFlBQVk7RUFDcEQsTUFBTSxZQUFZLGFBQWEsUUFBUSxXQUFXO0VBRWxELElBQUksY0FBYyxXQUFXO0dBQzNCLElBQUk7SUFDRixTQUFTLFVBQVU7SUFDbkIsUUFBUSxLQUFLLE1BQU0sU0FBUyxDQUFDO0lBQzdCLElBQUksU0FBUyxRQUFRLE9BQU8sbUJBQW1CLFVBQVU7O0lBRXpELElBQUksU0FBUyxRQUFRLE9BQU8sb0JBQW9CLEtBQUssTUFBTSxTQUFTLENBQUMsQ0FBQztHQUN4RSxTQUFTLEdBQUc7SUFDVixPQUFPO0dBQ1Q7RUFDRjtFQUNBLGFBQWEsS0FBSztDQUNwQixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sU0FBUyxVQUFrQixTQUFlLGdCQUF3QjtFQUN0RSxNQUFNLFdBQVc7R0FBRSxHQUFHO0dBQVMsY0FBYztFQUFZO0VBQ3pELFNBQVMsUUFBUTtFQUNqQixRQUFRLFFBQVE7RUFDaEIsYUFBYSxRQUFRLGNBQWMsUUFBUTtFQUMzQyxhQUFhLFFBQVEsYUFBYSxLQUFLLFVBQVUsUUFBUSxDQUFDO0VBRTFELElBQUksU0FBUyxRQUFRLE9BQU8sbUJBQW1CLFVBQVU7RUFDekQsSUFBSSxTQUFTLFFBQVEsT0FBTyxvQkFBb0I7Q0FDbEQ7Q0FFQSxNQUFNLGVBQWU7RUFDbkIsU0FBUyxJQUFJO0VBQ2IsUUFBUSxJQUFJO0VBQ1osYUFBYSxXQUFXLFlBQVk7RUFDcEMsYUFBYSxXQUFXLFdBQVc7RUFFbkMsT0FBTyxJQUFJLFNBQVMsUUFBUSxPQUFPO0VBQ25DLE9BQU8sSUFBSSxTQUFTLFFBQVEsT0FBTztDQUNyQztDQUVBLE9BQ0Usd0JBQUMsWUFBWSxVQUFiO0VBQXNCLE9BQU87R0FBRTtHQUFNO0dBQU8saUJBQWlCLENBQUMsQ0FBQztHQUFPO0dBQU87R0FBUTtFQUFVO0VBQzVGO0NBQ21COzs7OztBQUUxQjs7O0FBRUEsT0FBTyxNQUFNLGdCQUFnQjs7Q0FDM0IsTUFBTSxVQUFVLFdBQVcsV0FBVztDQUN0QyxJQUFJLFlBQVksV0FBVztFQUN6QixNQUFNLElBQUksTUFBTSw2Q0FBNkM7Q0FDL0Q7Q0FDQSxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXV0aENvbnRleHQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSAnLi4vbGliL2FwaSc7XG5cbmludGVyZmFjZSBVc2VyIHtcbiAgaWQ6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgcm9sZTogc3RyaW5nO1xuICB3b3Jrc3BhY2VfaWQ6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIEF1dGhDb250ZXh0VHlwZSB7XG4gIHVzZXI6IFVzZXIgfCBudWxsO1xuICB0b2tlbjogc3RyaW5nIHwgbnVsbDtcbiAgaXNBdXRoZW50aWNhdGVkOiBib29sZWFuO1xuICBsb2dpbjogKHRva2VuOiBzdHJpbmcsIHVzZXI6IFVzZXIsIHdvcmtzcGFjZV9pZDogc3RyaW5nKSA9PiB2b2lkO1xuICBsb2dvdXQ6ICgpID0+IHZvaWQ7XG4gIGlzTG9hZGluZzogYm9vbGVhbjtcbn1cblxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0PEF1dGhDb250ZXh0VHlwZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcblxuZXhwb3J0IGNvbnN0IEF1dGhQcm92aWRlcjogUmVhY3QuRkM8eyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0+ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZTxVc2VyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt0b2tlbiwgc2V0VG9rZW5dID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIC8vIENoZWNrIGZvciBzYXZlZCBhdXRoIHN0YXRlIG9uIG1vdW50XG4gICAgY29uc3Qgc2F2ZWRUb2tlbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhdXRoX3Rva2VuJyk7XG4gICAgY29uc3Qgc2F2ZWRVc2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2F1dGhfdXNlcicpO1xuICAgIFxuICAgIGlmIChzYXZlZFRva2VuICYmIHNhdmVkVXNlcikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgc2V0VG9rZW4oc2F2ZWRUb2tlbik7XG4gICAgICAgIHNldFVzZXIoSlNPTi5wYXJzZShzYXZlZFVzZXIpKTtcbiAgICAgICAgYXBpLmRlZmF1bHRzLmhlYWRlcnMuY29tbW9uWydBdXRob3JpemF0aW9uJ10gPSBgQmVhcmVyICR7c2F2ZWRUb2tlbn1gO1xuICAgICAgICAvLyBBdXRvbWF0aWNhbGx5IGluamVjdCB3b3Jrc3BhY2VJZCB0byBhbGwgcmVxdWVzdHMgdXNpbmcgYXhpb3MgaW50ZXJjZXB0b3JcbiAgICAgICAgYXBpLmRlZmF1bHRzLmhlYWRlcnMuY29tbW9uWyd4LXdvcmtzcGFjZS1pZCddID0gSlNPTi5wYXJzZShzYXZlZFVzZXIpLndvcmtzcGFjZV9pZDtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgbG9nb3V0KCk7XG4gICAgICB9XG4gICAgfVxuICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBsb2dpbiA9IChuZXdUb2tlbjogc3RyaW5nLCBuZXdVc2VyOiBVc2VyLCB3b3Jrc3BhY2VJZDogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgZnVsbFVzZXIgPSB7IC4uLm5ld1VzZXIsIHdvcmtzcGFjZV9pZDogd29ya3NwYWNlSWQgfTtcbiAgICBzZXRUb2tlbihuZXdUb2tlbik7XG4gICAgc2V0VXNlcihmdWxsVXNlcik7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2F1dGhfdG9rZW4nLCBuZXdUb2tlbik7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2F1dGhfdXNlcicsIEpTT04uc3RyaW5naWZ5KGZ1bGxVc2VyKSk7XG4gICAgXG4gICAgYXBpLmRlZmF1bHRzLmhlYWRlcnMuY29tbW9uWydBdXRob3JpemF0aW9uJ10gPSBgQmVhcmVyICR7bmV3VG9rZW59YDtcbiAgICBhcGkuZGVmYXVsdHMuaGVhZGVycy5jb21tb25bJ3gtd29ya3NwYWNlLWlkJ10gPSB3b3Jrc3BhY2VJZDtcbiAgfTtcblxuICBjb25zdCBsb2dvdXQgPSAoKSA9PiB7XG4gICAgc2V0VG9rZW4obnVsbCk7XG4gICAgc2V0VXNlcihudWxsKTtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYXV0aF90b2tlbicpO1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdhdXRoX3VzZXInKTtcbiAgICBcbiAgICBkZWxldGUgYXBpLmRlZmF1bHRzLmhlYWRlcnMuY29tbW9uWydBdXRob3JpemF0aW9uJ107XG4gICAgZGVsZXRlIGFwaS5kZWZhdWx0cy5oZWFkZXJzLmNvbW1vblsneC13b3Jrc3BhY2UtaWQnXTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyB1c2VyLCB0b2tlbiwgaXNBdXRoZW50aWNhdGVkOiAhIXRva2VuLCBsb2dpbiwgbG9nb3V0LCBpc0xvYWRpbmcgfX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9BdXRoQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCB1c2VBdXRoID0gKCkgPT4ge1xuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChBdXRoQ29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3VzZUF1dGggbXVzdCBiZSB1c2VkIHdpdGhpbiBhbiBBdXRoUHJvdmlkZXInKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn07XG4iXX0=