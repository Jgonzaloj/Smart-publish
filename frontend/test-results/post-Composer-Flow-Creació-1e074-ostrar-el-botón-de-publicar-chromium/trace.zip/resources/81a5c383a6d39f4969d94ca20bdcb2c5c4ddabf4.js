import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/Login.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03b8b458";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=03b8b458";
import { api } from "/src/lib/api.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
import { Loader2, Mail, Lock, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=03b8b458";
var _jsxFileName = "C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Login.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03b8b458";
var _s = $RefreshSig$();
export const Login = () => {
	_s();
	const navigate = useNavigate();
	const { login } = useAuth();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	const handleSubmit = async (e) => {
		e.preventDefault();
		setIsLoading(true);
		setError("");
		try {
			const response = await api.post("/auth/login", {
				email,
				password
			});
			if (response.data.success) {
				login(response.data.token, response.data.user, response.data.workspace_id);
				navigate("/");
			}
		} catch (err) {
			setError(err.response?.data?.message || "Error al iniciar sesión. Verifica tus credenciales.");
		} finally {
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h2", {
			className: "text-3xl font-bold tracking-tight text-slate-900 dark:text-white mb-2",
			children: "Bienvenido de nuevo"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", {
			className: "text-slate-500 mb-8",
			children: "Ingresa a tu cuenta para continuar gestionando."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this),
		error && /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 p-4 rounded-xl flex items-start gap-3 mb-6 border border-red-200 dark:border-red-800",
			children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
				size: 20,
				className: "shrink-0 mt-0.5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm font-medium",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "space-y-5",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
						children: "Correo Electrónico"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV(Mail, {
							className: "absolute left-3 top-1/2 -translate-y-1/2 text-slate-400",
							size: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value),
							className: "input-field pl-10",
							placeholder: "tu@correo.com"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
							children: "Contraseña"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("a", {
							href: "#",
							className: "text-sm text-brand-600 hover:text-brand-500 font-medium",
							children: "¿Olvidaste tu contraseña?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV(Lock, {
							className: "absolute left-3 top-1/2 -translate-y-1/2 text-slate-400",
							size: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "password",
							required: true,
							value: password,
							onChange: (e) => setPassword(e.target.value),
							className: "input-field pl-10",
							placeholder: "••••••••"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isLoading,
					className: "w-full btn-primary justify-center py-3 mt-4",
					children: isLoading ? /* @__PURE__ */ _jsxDEV(Loader2, {
						className: "animate-spin",
						size: 20
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 24
					}, this) : "Iniciar Sesión"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", {
			className: "text-center mt-8 text-sm text-slate-500",
			children: ["¿No tienes una cuenta? ", /* @__PURE__ */ _jsxDEV(Link, {
				to: "/register",
				className: "text-brand-600 font-bold hover:underline",
				children: "Regístrate gratis"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 32
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this);
};
_s(Login, "aXuahD6sEWGGXt6x3kT4zSV1hB4=", false, function() {
	return [useNavigate, useAuth];
});
_c = Login;
var _c;
$RefreshReg$(_c, "Login");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/auth/Login.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Login.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Login.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Login.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLFdBQVc7QUFDcEIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsU0FBUyxNQUFNLE1BQU0sbUJBQW1COzs7O0FBRWpELE9BQU8sTUFBTSxjQUFjOztDQUN6QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLEVBQUUsVUFBVSxRQUFRO0NBRTFCLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsTUFBTSxlQUFlLE9BQU8sTUFBdUI7RUFDakQsRUFBRSxlQUFlO0VBQ2pCLGFBQWEsSUFBSTtFQUNqQixTQUFTLEVBQUU7RUFFWCxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLGVBQWU7SUFBRTtJQUFPO0dBQVMsQ0FBQztHQUVsRSxJQUFJLFNBQVMsS0FBSyxTQUFTO0lBQ3pCLE1BQU0sU0FBUyxLQUFLLE9BQU8sU0FBUyxLQUFLLE1BQU0sU0FBUyxLQUFLLFlBQVk7SUFDekUsU0FBUyxHQUFHO0dBQ2Q7RUFDRixTQUFTLEtBQVU7R0FDakIsU0FBUyxJQUFJLFVBQVUsTUFBTSxXQUFXLHFEQUFxRDtFQUMvRixVQUFVO0dBQ1IsYUFBYSxLQUFLO0VBQ3BCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUF3RTtFQUF1Qjs7Ozs7RUFDN0csd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBc0I7RUFBa0Q7Ozs7O0VBRXBGLFNBQ0Msd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLGFBQUQ7SUFBYSxNQUFNO0lBQUksV0FBVTtHQUFtQjs7OzthQUNwRCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF1QjtHQUFTOzs7O1dBQzFDOzs7Ozs7RUFHUCx3QkFBQyxRQUFEO0dBQU0sVUFBVTtHQUFjLFdBQVU7YUFBeEM7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQTJEO0tBQXlCOzs7O2VBQ3JHLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBMEQsTUFBTTtNQUFLOzs7O2dCQUNyRix3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMO09BQ0EsT0FBTztPQUNQLFdBQVUsTUFBSyxTQUFTLEVBQUUsT0FBTyxLQUFLO09BQ3RDLFdBQVU7T0FDVixhQUFZO01BQ2I7Ozs7Y0FDRTs7Ozs7YUFDRjs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQTJEO01BQWlCOzs7O2dCQUM3Rix3QkFBQyxLQUFEO09BQUcsTUFBSztPQUFJLFdBQVU7aUJBQTBEO01BQTRCOzs7O2NBQ3pHOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBMEQsTUFBTTtNQUFLOzs7O2dCQUNyRix3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMO09BQ0EsT0FBTztPQUNQLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxLQUFLO09BQ3pDLFdBQVU7T0FDVixhQUFZO01BQ2I7Ozs7Y0FDRTs7Ozs7YUFDRjs7Ozs7O0lBRUwsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxVQUFVO0tBQ1YsV0FBVTtlQUVULFlBQVksd0JBQUMsU0FBRDtNQUFTLFdBQVU7TUFBZSxNQUFNO0tBQUs7Ozs7Z0JBQUk7SUFDeEQ7Ozs7O0dBQ0o7Ozs7OztFQUVOLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQWIsQ0FBdUQsMkJBQzlCLHdCQUFDLE1BQUQ7SUFBTSxJQUFHO0lBQVksV0FBVTtjQUEyQztHQUF1Qjs7OztXQUN2SDs7Ozs7O0NBQ0E7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IGFwaSB9IGZyb20gJy4uLy4uL2xpYi9hcGknO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0JztcbmltcG9ydCB7IExvYWRlcjIsIE1haWwsIExvY2ssIEFsZXJ0Q2lyY2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGNvbnN0IExvZ2luID0gKCkgPT4ge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgbG9naW4gfSA9IHVzZUF1dGgoKTtcbiAgXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IoJycpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoJy9hdXRoL2xvZ2luJywgeyBlbWFpbCwgcGFzc3dvcmQgfSk7XG4gICAgICBcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhLnN1Y2Nlc3MpIHtcbiAgICAgICAgbG9naW4ocmVzcG9uc2UuZGF0YS50b2tlbiwgcmVzcG9uc2UuZGF0YS51c2VyLCByZXNwb25zZS5kYXRhLndvcmtzcGFjZV9pZCk7XG4gICAgICAgIG5hdmlnYXRlKCcvJyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEVycm9yKGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCAnRXJyb3IgYWwgaW5pY2lhciBzZXNpw7NuLiBWZXJpZmljYSB0dXMgY3JlZGVuY2lhbGVzLicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtYi0yXCI+QmllbnZlbmlkbyBkZSBudWV2bzwvaDI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBtYi04XCI+SW5ncmVzYSBhIHR1IGN1ZW50YSBwYXJhIGNvbnRpbnVhciBnZXN0aW9uYW5kby48L3A+XG5cbiAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTUwIGRhcms6YmctcmVkLTkwMC8zMCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgcC00IHJvdW5kZWQteGwgZmxleCBpdGVtcy1zdGFydCBnYXAtMyBtYi02IGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwXCI+XG4gICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezIwfSBjbGFzc05hbWU9XCJzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj57ZXJyb3J9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPkNvcnJlbyBFbGVjdHLDs25pY288L2xhYmVsPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgIDxNYWlsIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1zbGF0ZS00MDBcIiBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCIgXG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZCBwbC0xMFwiIFxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInR1QGNvcnJlby5jb21cIiBcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPkNvbnRyYXNlw7FhPC9sYWJlbD5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJyYW5kLTYwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBmb250LW1lZGl1bVwiPsK/T2x2aWRhc3RlIHR1IGNvbnRyYXNlw7FhPzwvYT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwXCIgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiIFxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGQgcGwtMTBcIiBcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIiBcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgdHlwZT1cInN1Ym1pdFwiIFxuICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJ0bi1wcmltYXJ5IGp1c3RpZnktY2VudGVyIHB5LTMgbXQtNFwiXG4gICAgICAgID5cbiAgICAgICAgICB7aXNMb2FkaW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgc2l6ZT17MjB9IC8+IDogJ0luaWNpYXIgU2VzacOzbid9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtdC04IHRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgwr9ObyB0aWVuZXMgdW5hIGN1ZW50YT8gPExpbmsgdG89XCIvcmVnaXN0ZXJcIiBjbGFzc05hbWU9XCJ0ZXh0LWJyYW5kLTYwMCBmb250LWJvbGQgaG92ZXI6dW5kZXJsaW5lXCI+UmVnw61zdHJhdGUgZ3JhdGlzPC9MaW5rPlxuICAgICAgPC9wPlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==