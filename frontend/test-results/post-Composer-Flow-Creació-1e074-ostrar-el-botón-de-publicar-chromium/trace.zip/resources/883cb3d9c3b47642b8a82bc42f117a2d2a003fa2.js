import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/Register.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03b8b458";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=03b8b458";
import { api } from "/src/lib/api.ts";
import { Loader2, Mail, Lock, User, AlertCircle, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=03b8b458";
var _jsxFileName = "C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Register.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03b8b458";
var _s = $RefreshSig$();
export const Register = () => {
	_s();
	const navigate = useNavigate();
	const [name, setName] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	const [success, setSuccess] = useState(false);
	const handleSubmit = async (e) => {
		e.preventDefault();
		setIsLoading(true);
		setError("");
		try {
			const response = await api.post("/auth/register", {
				name,
				email,
				password
			});
			if (response.data.success) {
				setSuccess(true);
				setTimeout(() => {
					navigate("/login");
				}, 2e3);
			}
		} catch (err) {
			setError(err.response?.data?.message || "Error al registrar usuario. Intenta nuevamente.");
		} finally {
			setIsLoading(false);
		}
	};
	if (success) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6",
					children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 32 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-bold mb-2 text-slate-900 dark:text-white",
					children: "¡Registro Exitoso!"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 mb-8",
					children: "Tu cuenta ha sido creada. Redirigiendo al inicio de sesión..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h2", {
			className: "text-3xl font-bold tracking-tight text-slate-900 dark:text-white mb-2",
			children: "Crea tu cuenta"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", {
			className: "text-slate-500 mb-8",
			children: "Comienza a probar Smart Publish gratis por 14 días."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this),
		error && /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 p-4 rounded-xl flex items-start gap-3 mb-6 border border-red-200 dark:border-red-800",
			children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
				size: 20,
				className: "shrink-0 mt-0.5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm font-medium",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
						children: "Nombre Completo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV(User, {
							className: "absolute left-3 top-1/2 -translate-y-1/2 text-slate-400",
							size: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							required: true,
							value: name,
							onChange: (e) => setName(e.target.value),
							className: "input-field pl-10",
							placeholder: "Juan Pérez"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
						children: "Correo Electrónico"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV(Mail, {
							className: "absolute left-3 top-1/2 -translate-y-1/2 text-slate-400",
							size: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value),
							className: "input-field pl-10",
							placeholder: "tu@correo.com"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
						children: "Contraseña"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV(Lock, {
							className: "absolute left-3 top-1/2 -translate-y-1/2 text-slate-400",
							size: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "password",
							required: true,
							minLength: 6,
							value: password,
							onChange: (e) => setPassword(e.target.value),
							className: "input-field pl-10",
							placeholder: "••••••••"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isLoading,
					className: "w-full btn-primary justify-center py-3 mt-6",
					children: isLoading ? /* @__PURE__ */ _jsxDEV(Loader2, {
						className: "animate-spin",
						size: 20
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 24
					}, this) : "Crear Cuenta"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", {
			className: "text-center mt-8 text-sm text-slate-500",
			children: ["¿Ya tienes una cuenta? ", /* @__PURE__ */ _jsxDEV(Link, {
				to: "/login",
				className: "text-brand-600 font-bold hover:underline",
				children: "Inicia sesión"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 32
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 5
	}, this);
};
_s(Register, "N0ZAYggIg94ftv49K9y+0MoKCaQ=", false, function() {
	return [useNavigate];
});
_c = Register;
var _c;
$RefreshReg$(_c, "Register");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/auth/Register.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Register.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Register.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/auth/Register.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLFdBQVc7QUFDcEIsU0FBUyxTQUFTLE1BQU0sTUFBTSxNQUFNLGFBQWEsb0JBQW9COzs7O0FBRXJFLE9BQU8sTUFBTSxpQkFBaUI7O0NBQzVCLE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBQ25DLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FFNUMsTUFBTSxlQUFlLE9BQU8sTUFBdUI7RUFDakQsRUFBRSxlQUFlO0VBQ2pCLGFBQWEsSUFBSTtFQUNqQixTQUFTLEVBQUU7RUFFWCxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLGtCQUFrQjtJQUFFO0lBQU07SUFBTztHQUFTLENBQUM7R0FFM0UsSUFBSSxTQUFTLEtBQUssU0FBUztJQUN6QixXQUFXLElBQUk7SUFDZixpQkFBaUI7S0FDZixTQUFTLFFBQVE7SUFDbkIsR0FBRyxHQUFJO0dBQ1Q7RUFDRixTQUFTLEtBQVU7R0FDakIsU0FBUyxJQUFJLFVBQVUsTUFBTSxXQUFXLGlEQUFpRDtFQUMzRixVQUFVO0dBQ1IsYUFBYSxLQUFLO0VBQ3BCO0NBQ0Y7Q0FFQSxJQUFJLFNBQVM7RUFDWCxPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O0lBQ3RCOzs7OztJQUNMLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXlEO0lBQXNCOzs7OztJQUM3Rix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFzQjtJQUFnRTs7Ozs7R0FDaEc7Ozs7OztDQUVUO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQ0Usd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBd0U7RUFBa0I7Ozs7O0VBQ3hHLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQXNCO0VBQXNEOzs7OztFQUV4RixTQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxhQUFEO0lBQWEsTUFBTTtJQUFJLFdBQVU7R0FBbUI7Ozs7YUFDcEQsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBdUI7R0FBUzs7OztXQUMxQzs7Ozs7O0VBR1Asd0JBQUMsUUFBRDtHQUFNLFVBQVU7R0FBYyxXQUFVO2FBQXhDO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUEyRDtLQUFzQjs7OztlQUNsRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBTSxXQUFVO09BQTBELE1BQU07TUFBSzs7OztnQkFDckYsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTDtPQUNBLE9BQU87T0FDUCxXQUFVLE1BQUssUUFBUSxFQUFFLE9BQU8sS0FBSztPQUNyQyxXQUFVO09BQ1YsYUFBWTtNQUNiOzs7O2NBQ0U7Ozs7O2FBQ0Y7Ozs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBMkQ7S0FBeUI7Ozs7ZUFDckcsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQU0sV0FBVTtPQUEwRCxNQUFNO01BQUs7Ozs7Z0JBQ3JGLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0w7T0FDQSxPQUFPO09BQ1AsV0FBVSxNQUFLLFNBQVMsRUFBRSxPQUFPLEtBQUs7T0FDdEMsV0FBVTtPQUNWLGFBQVk7TUFDYjs7OztjQUNFOzs7OzthQUNGOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQTJEO0tBQWlCOzs7O2VBQzdGLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFNLFdBQVU7T0FBMEQsTUFBTTtNQUFLOzs7O2dCQUNyRix3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMO09BQ0EsV0FBVztPQUNYLE9BQU87T0FDUCxXQUFVLE1BQUssWUFBWSxFQUFFLE9BQU8sS0FBSztPQUN6QyxXQUFVO09BQ1YsYUFBWTtNQUNiOzs7O2NBQ0U7Ozs7O2FBQ0Y7Ozs7OztJQUVMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsVUFBVTtLQUNWLFdBQVU7ZUFFVCxZQUFZLHdCQUFDLFNBQUQ7TUFBUyxXQUFVO01BQWUsTUFBTTtLQUFLOzs7O2dCQUFJO0lBQ3hEOzs7OztHQUNKOzs7Ozs7RUFFTix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFiLENBQXVELDJCQUM5Qix3QkFBQyxNQUFEO0lBQU0sSUFBRztJQUFTLFdBQVU7Y0FBMkM7R0FBbUI7Ozs7V0FDaEg7Ozs7OztDQUNBOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBhcGkgfSBmcm9tICcuLi8uLi9saWIvYXBpJztcbmltcG9ydCB7IExvYWRlcjIsIE1haWwsIExvY2ssIFVzZXIsIEFsZXJ0Q2lyY2xlLCBDaGVja0NpcmNsZTIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgY29uc3QgUmVnaXN0ZXIgPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgXG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3N1Y2Nlc3MsIHNldFN1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKCcnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KCcvYXV0aC9yZWdpc3RlcicsIHsgbmFtZSwgZW1haWwsIHBhc3N3b3JkIH0pO1xuICAgICAgXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XG4gICAgICAgIHNldFN1Y2Nlc3ModHJ1ZSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgICAgICAgfSwgMjAwMCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEVycm9yKGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCAnRXJyb3IgYWwgcmVnaXN0cmFyIHVzdWFyaW8uIEludGVudGEgbnVldmFtZW50ZS4nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgaWYgKHN1Y2Nlc3MpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiBiZy1lbWVyYWxkLTEwMCBkYXJrOmJnLWVtZXJhbGQtOTAwLzMwIHRleHQtZW1lcmFsZC01MDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNlwiPlxuICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MzJ9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG1iLTIgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+wqFSZWdpc3RybyBFeGl0b3NvITwvaDI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIG1iLThcIj5UdSBjdWVudGEgaGEgc2lkbyBjcmVhZGEuIFJlZGlyaWdpZW5kbyBhbCBpbmljaW8gZGUgc2VzacOzbi4uLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtYi0yXCI+Q3JlYSB0dSBjdWVudGE8L2gyPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgbWItOFwiPkNvbWllbnphIGEgcHJvYmFyIFNtYXJ0IFB1Ymxpc2ggZ3JhdGlzIHBvciAxNCBkw61hcy48L3A+XG5cbiAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTUwIGRhcms6YmctcmVkLTkwMC8zMCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgcC00IHJvdW5kZWQteGwgZmxleCBpdGVtcy1zdGFydCBnYXAtMyBtYi02IGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwXCI+XG4gICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezIwfSBjbGFzc05hbWU9XCJzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj57ZXJyb3J9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPk5vbWJyZSBDb21wbGV0bzwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXNsYXRlLTQwMFwiIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICB2YWx1ZT17bmFtZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkIHBsLTEwXCIgXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSnVhbiBQw6lyZXpcIiBcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+Q29ycmVvIEVsZWN0csOzbmljbzwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXNsYXRlLTQwMFwiIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIiBcbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkIHBsLTEwXCIgXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwidHVAY29ycmVvLmNvbVwiIFxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5Db250cmFzZcOxYTwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXNsYXRlLTQwMFwiIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIiBcbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgbWluTGVuZ3RoPXs2fVxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGQgcGwtMTBcIiBcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIiBcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgdHlwZT1cInN1Ym1pdFwiIFxuICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJ0bi1wcmltYXJ5IGp1c3RpZnktY2VudGVyIHB5LTMgbXQtNlwiXG4gICAgICAgID5cbiAgICAgICAgICB7aXNMb2FkaW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgc2l6ZT17MjB9IC8+IDogJ0NyZWFyIEN1ZW50YSd9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtdC04IHRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgwr9ZYSB0aWVuZXMgdW5hIGN1ZW50YT8gPExpbmsgdG89XCIvbG9naW5cIiBjbGFzc05hbWU9XCJ0ZXh0LWJyYW5kLTYwMCBmb250LWJvbGQgaG92ZXI6dW5kZXJsaW5lXCI+SW5pY2lhIHNlc2nDs248L0xpbms+XG4gICAgICA8L3A+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19