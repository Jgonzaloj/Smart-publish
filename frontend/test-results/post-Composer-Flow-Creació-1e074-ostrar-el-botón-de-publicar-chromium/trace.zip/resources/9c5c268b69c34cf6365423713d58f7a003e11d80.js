import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const Suspense = __vite__cjsImport0_react["Suspense"]; const lazy = __vite__cjsImport0_react["lazy"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03b8b458";
import { BrowserRouter, Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=03b8b458";
import { AppLayout } from "/src/components/layout/AppLayout.tsx";
import { AuthLayout } from "/src/components/layout/AuthLayout.tsx";
import { AuthProvider, useAuth } from "/src/contexts/AuthContext.tsx";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=03b8b458";
var _jsxFileName = "C:/Users/Admin/Desktop/smart-publish/frontend/src/App.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03b8b458";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Lazy Loading para optimizar el bundle inicial
const Dashboard = lazy(_c = () => import("/src/pages/Dashboard.tsx").then((module) => ({ default: module.Dashboard })));
_c2 = Dashboard;
const Composer = lazy(_c3 = () => import("/src/pages/Composer.tsx").then((module) => ({ default: module.Composer })));
_c4 = Composer;
const Settings = lazy(_c5 = () => import("/src/pages/Settings.tsx").then((module) => ({ default: module.Settings })));
_c6 = Settings;
const FacebookCallback = lazy(_c7 = () => import("/src/pages/FacebookCallback.tsx").then((module) => ({ default: module.FacebookCallback })));
_c8 = FacebookCallback;
const LinkedInCallback = lazy(_c9 = () => import("/src/pages/LinkedInCallback.tsx").then((module) => ({ default: module.LinkedInCallback })));
_c10 = LinkedInCallback;
const TikTokCallback = lazy(_c11 = () => import("/src/pages/TikTokCallback.tsx").then((module) => ({ default: module.TikTokCallback })));
_c12 = TikTokCallback;
const Campaigns = lazy(_c13 = () => import("/src/pages/Campaigns.tsx").then((module) => ({ default: module.Campaigns })));
_c14 = Campaigns;
const Calendar = lazy(_c15 = () => import("/src/pages/Calendar.tsx").then((module) => ({ default: module.Calendar })));
_c16 = Calendar;
const Billing = lazy(_c17 = () => import("/src/pages/Billing.tsx").then((module) => ({ default: module.Billing })));
_c18 = Billing;
const SuperAdmin = lazy(_c19 = () => import("/src/pages/SuperAdmin.tsx").then((module) => ({ default: module.SuperAdmin })));
_c20 = SuperAdmin;
// Páginas de Auth
const Login = lazy(_c21 = () => import("/src/pages/auth/Login.tsx").then((module) => ({ default: module.Login })));
_c22 = Login;
const Register = lazy(_c23 = () => import("/src/pages/auth/Register.tsx").then((module) => ({ default: module.Register })));
_c24 = Register;
const ForgotPassword = lazy(_c25 = () => import("/src/pages/auth/ForgotPassword.tsx").then((module) => ({ default: module.ForgotPassword })));
_c26 = ForgotPassword;
const ResetPassword = lazy(_c27 = () => import("/src/pages/auth/ResetPassword.tsx").then((module) => ({ default: module.ResetPassword })));
_c28 = ResetPassword;
const LoadingFallback = () => /* @__PURE__ */ _jsxDEV("div", {
	className: "flex items-center justify-center h-full w-full min-h-screen",
	children: /* @__PURE__ */ _jsxDEV(Loader2, {
		className: "animate-spin text-brand-500",
		size: 40
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 27,
	columnNumber: 3
}, this);
_c29 = LoadingFallback;
// Wrapper para Rutas Privadas (Requiere Login)
const ProtectedRoute = ({ children }) => {
	_s();
	const { isAuthenticated, isLoading } = useAuth();
	if (isLoading) return /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 25
	}, this);
	if (!isAuthenticated) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: "/login",
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 32
	}, this);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 10
	}, this);
};
_s(ProtectedRoute, "yb/FJYAIXt7wZoU4a4YvGQ4Nlsc=", false, function() {
	return [useAuth];
});
_c30 = ProtectedRoute;
// Wrapper para Rutas Públicas (Si ya estás logueado, te manda al Dashboard)
const PublicRoute = ({ children }) => {
	_s2();
	const { isAuthenticated, isLoading } = useAuth();
	if (isLoading) return /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 25
	}, this);
	if (isAuthenticated) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: "/",
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 31
	}, this);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 10
	}, this);
};
_s2(PublicRoute, "yb/FJYAIXt7wZoU4a4YvGQ4Nlsc=", false, function() {
	return [useAuth];
});
_c31 = PublicRoute;
function App() {
	return /* @__PURE__ */ _jsxDEV(AuthProvider, { children: /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: [/* @__PURE__ */ _jsxDEV(Route, {
		element: /* @__PURE__ */ _jsxDEV(PublicRoute, { children: /* @__PURE__ */ _jsxDEV(AuthLayout, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 40
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 27
		}, this),
		children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/login",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/register",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Register, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/forgot-password",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(ForgotPassword, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/reset-password",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(ResetPassword, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 11
	}, this), /* @__PURE__ */ _jsxDEV(Route, {
		path: "/",
		element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AppLayout, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 52
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 36
		}, this),
		children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				index: true,
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Dashboard, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "calendar",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Calendar, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "compose",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Composer, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "campaigns",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Campaigns, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "settings",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Settings, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "billing",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(Billing, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "callback/facebook",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(FacebookCallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "callback/linkedin",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(LinkedInCallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "callback/tiktok",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(TikTokCallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "superadmin",
				element: /* @__PURE__ */ _jsxDEV(Suspense, {
					fallback: /* @__PURE__ */ _jsxDEV(LoadingFallback, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 35
					}, this),
					children: /* @__PURE__ */ _jsxDEV(SuperAdmin, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 128,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 82,
		columnNumber: 11
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
}
_c32 = App;
export default App;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28, _c29, _c30, _c31, _c32;
$RefreshReg$(_c, "Dashboard$lazy");
$RefreshReg$(_c2, "Dashboard");
$RefreshReg$(_c3, "Composer$lazy");
$RefreshReg$(_c4, "Composer");
$RefreshReg$(_c5, "Settings$lazy");
$RefreshReg$(_c6, "Settings");
$RefreshReg$(_c7, "FacebookCallback$lazy");
$RefreshReg$(_c8, "FacebookCallback");
$RefreshReg$(_c9, "LinkedInCallback$lazy");
$RefreshReg$(_c10, "LinkedInCallback");
$RefreshReg$(_c11, "TikTokCallback$lazy");
$RefreshReg$(_c12, "TikTokCallback");
$RefreshReg$(_c13, "Campaigns$lazy");
$RefreshReg$(_c14, "Campaigns");
$RefreshReg$(_c15, "Calendar$lazy");
$RefreshReg$(_c16, "Calendar");
$RefreshReg$(_c17, "Billing$lazy");
$RefreshReg$(_c18, "Billing");
$RefreshReg$(_c19, "SuperAdmin$lazy");
$RefreshReg$(_c20, "SuperAdmin");
$RefreshReg$(_c21, "Login$lazy");
$RefreshReg$(_c22, "Login");
$RefreshReg$(_c23, "Register$lazy");
$RefreshReg$(_c24, "Register");
$RefreshReg$(_c25, "ForgotPassword$lazy");
$RefreshReg$(_c26, "ForgotPassword");
$RefreshReg$(_c27, "ResetPassword$lazy");
$RefreshReg$(_c28, "ResetPassword");
$RefreshReg$(_c29, "LoadingFallback");
$RefreshReg$(_c30, "ProtectedRoute");
$RefreshReg$(_c31, "PublicRoute");
$RefreshReg$(_c32, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Admin/Desktop/smart-publish/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Admin/Desktop/smart-publish/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Admin/Desktop/smart-publish/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFlBQVk7QUFDL0IsU0FBUyxlQUFlLFFBQVEsT0FBTyxnQkFBZ0I7QUFDdkQsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjLGVBQWU7QUFDdEMsU0FBUyxlQUFlOzs7OztBQUd4QixNQUFNLFlBQVksZ0JBQVcsT0FBTyxvQkFBb0IsQ0FBQyxNQUFLLFlBQVcsRUFBRSxTQUFTLE9BQU8sVUFBVSxFQUFFLENBQUM7O0FBQ3hHLE1BQU0sV0FBVyxpQkFBVyxPQUFPLG1CQUFtQixDQUFDLE1BQUssWUFBVyxFQUFFLFNBQVMsT0FBTyxTQUFTLEVBQUUsQ0FBQzs7QUFDckcsTUFBTSxXQUFXLGlCQUFXLE9BQU8sbUJBQW1CLENBQUMsTUFBSyxZQUFXLEVBQUUsU0FBUyxPQUFPLFNBQVMsRUFBRSxDQUFDOztBQUNyRyxNQUFNLG1CQUFtQixpQkFBVyxPQUFPLDJCQUEyQixDQUFDLE1BQUssWUFBVyxFQUFFLFNBQVMsT0FBTyxpQkFBaUIsRUFBRSxDQUFDOztBQUM3SCxNQUFNLG1CQUFtQixpQkFBVyxPQUFPLDJCQUEyQixDQUFDLE1BQUssWUFBVyxFQUFFLFNBQVMsT0FBTyxpQkFBaUIsRUFBRSxDQUFDOztBQUM3SCxNQUFNLGlCQUFpQixrQkFBVyxPQUFPLHlCQUF5QixDQUFDLE1BQUssWUFBVyxFQUFFLFNBQVMsT0FBTyxlQUFlLEVBQUUsQ0FBQzs7QUFDdkgsTUFBTSxZQUFZLGtCQUFXLE9BQU8sb0JBQW9CLENBQUMsTUFBSyxZQUFXLEVBQUUsU0FBUyxPQUFPLFVBQVUsRUFBRSxDQUFDOztBQUN4RyxNQUFNLFdBQVcsa0JBQVcsT0FBTyxtQkFBbUIsQ0FBQyxNQUFLLFlBQVcsRUFBRSxTQUFTLE9BQU8sU0FBUyxFQUFFLENBQUM7O0FBQ3JHLE1BQU0sVUFBVSxrQkFBVyxPQUFPLGtCQUFrQixDQUFDLE1BQUssWUFBVyxFQUFFLFNBQVMsT0FBTyxRQUFRLEVBQUUsQ0FBQzs7QUFDbEcsTUFBTSxhQUFhLGtCQUFXLE9BQU8scUJBQXFCLENBQUMsTUFBSyxZQUFXLEVBQUUsU0FBUyxPQUFPLFdBQVcsRUFBRSxDQUFDOzs7QUFHM0csTUFBTSxRQUFRLGtCQUFXLE9BQU8scUJBQXFCLENBQUMsTUFBSyxZQUFXLEVBQUUsU0FBUyxPQUFPLE1BQU0sRUFBRSxDQUFDOztBQUNqRyxNQUFNLFdBQVcsa0JBQVcsT0FBTyx3QkFBd0IsQ0FBQyxNQUFLLFlBQVcsRUFBRSxTQUFTLE9BQU8sU0FBUyxFQUFFLENBQUM7O0FBQzFHLE1BQU0saUJBQWlCLGtCQUFXLE9BQU8sOEJBQThCLENBQUMsTUFBSyxZQUFXLEVBQUUsU0FBUyxPQUFPLGVBQWUsRUFBRSxDQUFDOztBQUM1SCxNQUFNLGdCQUFnQixrQkFBVyxPQUFPLDZCQUE2QixDQUFDLE1BQUssWUFBVyxFQUFFLFNBQVMsT0FBTyxjQUFjLEVBQUUsQ0FBQzs7QUFFekgsTUFBTSx3QkFDSix3QkFBQyxPQUFEO0NBQUssV0FBVTtXQUNiLHdCQUFDLFNBQUQ7RUFBUyxXQUFVO0VBQThCLE1BQU07Q0FBSzs7Ozs7QUFDekQ7Ozs7Ozs7QUFJUCxNQUFNLGtCQUFrQixFQUFFLGVBQThDOztDQUN0RSxNQUFNLEVBQUUsaUJBQWlCLGNBQWMsUUFBUTtDQUUvQyxJQUFJLFdBQVcsT0FBTyx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7Q0FDeEMsSUFBSSxDQUFDLGlCQUFpQixPQUFPLHdCQUFDLFVBQUQ7RUFBVSxJQUFHO0VBQVM7Q0FBUzs7Ozs7Q0FFNUQsT0FBTyxxQ0FBRyxTQUFXOzs7OztBQUN2Qjs7Ozs7O0FBR0EsTUFBTSxlQUFlLEVBQUUsZUFBOEM7O0NBQ25FLE1BQU0sRUFBRSxpQkFBaUIsY0FBYyxRQUFRO0NBRS9DLElBQUksV0FBVyxPQUFPLHdCQUFDLGlCQUFELENBQWtCOzs7OztDQUN4QyxJQUFJLGlCQUFpQixPQUFPLHdCQUFDLFVBQUQ7RUFBVSxJQUFHO0VBQUk7Q0FBUzs7Ozs7Q0FFdEQsT0FBTyxxQ0FBRyxTQUFXOzs7OztBQUN2Qjs7Ozs7QUFFQSxTQUFTLE1BQU07Q0FDYixPQUNFLHdCQUFDLGNBQUQsWUFDRSx3QkFBQyxlQUFELFlBQ0Usd0JBQUMsUUFBRCxhQUVFLHdCQUFDLE9BQUQ7RUFBTyxTQUFTLHdCQUFDLGFBQUQsWUFBYSx3QkFBQyxZQUFELENBQWE7Ozs7V0FBYzs7Ozs7WUFBeEQ7R0FDRSx3QkFBQyxPQUFEO0lBQU8sTUFBSztJQUFTLFNBQ25CLHdCQUFDLFVBQUQ7S0FBVSxVQUFVLHdCQUFDLGlCQUFELENBQWtCOzs7OztlQUNwQyx3QkFBQyxPQUFELENBQVE7Ozs7O0lBQ0E7Ozs7O0dBQ1Q7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBWSxTQUN0Qix3QkFBQyxVQUFEO0tBQVUsVUFBVSx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7ZUFDcEMsd0JBQUMsVUFBRCxDQUFXOzs7OztJQUNIOzs7OztHQUNUOzs7OztHQUNILHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQW1CLFNBQzdCLHdCQUFDLFVBQUQ7S0FBVSxVQUFVLHdCQUFDLGlCQUFELENBQWtCOzs7OztlQUNwQyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7SUFDVDs7Ozs7R0FDVDs7Ozs7R0FDSCx3QkFBQyxPQUFEO0lBQU8sTUFBSztJQUFrQixTQUM1Qix3QkFBQyxVQUFEO0tBQVUsVUFBVSx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7ZUFDcEMsd0JBQUMsZUFBRCxDQUFnQjs7Ozs7SUFDUjs7Ozs7R0FDVDs7Ozs7RUFDRTs7Ozs7V0FHUCx3QkFBQyxPQUFEO0VBQU8sTUFBSztFQUFJLFNBQVMsd0JBQUMsZ0JBQUQsWUFBZ0Isd0JBQUMsV0FBRCxDQUFZOzs7O1dBQWlCOzs7OztZQUF0RTtHQUNFLHdCQUFDLE9BQUQ7SUFBTztJQUFNLFNBQ1gsd0JBQUMsVUFBRDtLQUFVLFVBQVUsd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O2VBQ3BDLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7SUFDSjs7Ozs7R0FDVDs7Ozs7R0FDSCx3QkFBQyxPQUFEO0lBQU8sTUFBSztJQUFXLFNBQ3JCLHdCQUFDLFVBQUQ7S0FBVSxVQUFVLHdCQUFDLGlCQUFELENBQWtCOzs7OztlQUNwQyx3QkFBQyxVQUFELENBQVc7Ozs7O0lBQ0g7Ozs7O0dBQ1Q7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBVSxTQUNwQix3QkFBQyxVQUFEO0tBQVUsVUFBVSx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7ZUFDcEMsd0JBQUMsVUFBRCxDQUFXOzs7OztJQUNIOzs7OztHQUNUOzs7OztHQUNILHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQVksU0FDdEIsd0JBQUMsVUFBRDtLQUFVLFVBQVUsd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O2VBQ3BDLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7SUFDSjs7Ozs7R0FDVDs7Ozs7R0FDSCx3QkFBQyxPQUFEO0lBQU8sTUFBSztJQUFXLFNBQ3JCLHdCQUFDLFVBQUQ7S0FBVSxVQUFVLHdCQUFDLGlCQUFELENBQWtCOzs7OztlQUNwQyx3QkFBQyxVQUFELENBQVc7Ozs7O0lBQ0g7Ozs7O0dBQ1Q7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBVSxTQUNwQix3QkFBQyxVQUFEO0tBQVUsVUFBVSx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7ZUFDcEMsd0JBQUMsU0FBRCxDQUFVOzs7OztJQUNGOzs7OztHQUNUOzs7OztHQUNILHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQW9CLFNBQzlCLHdCQUFDLFVBQUQ7S0FBVSxVQUFVLHdCQUFDLGlCQUFELENBQWtCOzs7OztlQUNwQyx3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7SUFDWDs7Ozs7R0FDVDs7Ozs7R0FDSCx3QkFBQyxPQUFEO0lBQU8sTUFBSztJQUFvQixTQUM5Qix3QkFBQyxVQUFEO0tBQVUsVUFBVSx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7ZUFDcEMsd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7O0lBQ1g7Ozs7O0dBQ1Q7Ozs7O0dBQ0gsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBa0IsU0FDNUIsd0JBQUMsVUFBRDtLQUFVLFVBQVUsd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O2VBQ3BDLHdCQUFDLGdCQUFELENBQWlCOzs7OztJQUNUOzs7OztHQUNUOzs7OztHQUNILHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQWEsU0FDdkIsd0JBQUMsVUFBRDtLQUFVLFVBQVUsd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O2VBQ3BDLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7SUFDTDs7Ozs7R0FDVDs7Ozs7RUFDRTs7Ozs7U0FDRDs7OztVQUNLOzs7O1VBQ0g7Ozs7O0FBRWxCOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdXNwZW5zZSwgbGF6eSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIsIFJvdXRlcywgUm91dGUsIE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBBcHBMYXlvdXQgfSBmcm9tICcuL2NvbXBvbmVudHMvbGF5b3V0L0FwcExheW91dCc7XG5pbXBvcnQgeyBBdXRoTGF5b3V0IH0gZnJvbSAnLi9jb21wb25lbnRzL2xheW91dC9BdXRoTGF5b3V0JztcbmltcG9ydCB7IEF1dGhQcm92aWRlciwgdXNlQXV0aCB9IGZyb20gJy4vY29udGV4dHMvQXV0aENvbnRleHQnO1xuaW1wb3J0IHsgTG9hZGVyMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbi8vIExhenkgTG9hZGluZyBwYXJhIG9wdGltaXphciBlbCBidW5kbGUgaW5pY2lhbFxuY29uc3QgRGFzaGJvYXJkID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4vcGFnZXMvRGFzaGJvYXJkJykudGhlbihtb2R1bGUgPT4gKHsgZGVmYXVsdDogbW9kdWxlLkRhc2hib2FyZCB9KSkpO1xuY29uc3QgQ29tcG9zZXIgPSBsYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9Db21wb3NlcicpLnRoZW4obW9kdWxlID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5Db21wb3NlciB9KSkpO1xuY29uc3QgU2V0dGluZ3MgPSBsYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9TZXR0aW5ncycpLnRoZW4obW9kdWxlID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5TZXR0aW5ncyB9KSkpO1xuY29uc3QgRmFjZWJvb2tDYWxsYmFjayA9IGxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL0ZhY2Vib29rQ2FsbGJhY2snKS50aGVuKG1vZHVsZSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuRmFjZWJvb2tDYWxsYmFjayB9KSkpO1xuY29uc3QgTGlua2VkSW5DYWxsYmFjayA9IGxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL0xpbmtlZEluQ2FsbGJhY2snKS50aGVuKG1vZHVsZSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuTGlua2VkSW5DYWxsYmFjayB9KSkpO1xuY29uc3QgVGlrVG9rQ2FsbGJhY2sgPSBsYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9UaWtUb2tDYWxsYmFjaycpLnRoZW4obW9kdWxlID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5UaWtUb2tDYWxsYmFjayB9KSkpO1xuY29uc3QgQ2FtcGFpZ25zID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4vcGFnZXMvQ2FtcGFpZ25zJykudGhlbihtb2R1bGUgPT4gKHsgZGVmYXVsdDogbW9kdWxlLkNhbXBhaWducyB9KSkpO1xuY29uc3QgQ2FsZW5kYXIgPSBsYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9DYWxlbmRhcicpLnRoZW4obW9kdWxlID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5DYWxlbmRhciB9KSkpO1xuY29uc3QgQmlsbGluZyA9IGxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL0JpbGxpbmcnKS50aGVuKG1vZHVsZSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuQmlsbGluZyB9KSkpO1xuY29uc3QgU3VwZXJBZG1pbiA9IGxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL1N1cGVyQWRtaW4nKS50aGVuKG1vZHVsZSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuU3VwZXJBZG1pbiB9KSkpO1xuXG4vLyBQw6FnaW5hcyBkZSBBdXRoXG5jb25zdCBMb2dpbiA9IGxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL2F1dGgvTG9naW4nKS50aGVuKG1vZHVsZSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuTG9naW4gfSkpKTtcbmNvbnN0IFJlZ2lzdGVyID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4vcGFnZXMvYXV0aC9SZWdpc3RlcicpLnRoZW4obW9kdWxlID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5SZWdpc3RlciB9KSkpO1xuY29uc3QgRm9yZ290UGFzc3dvcmQgPSBsYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9hdXRoL0ZvcmdvdFBhc3N3b3JkJykudGhlbihtb2R1bGUgPT4gKHsgZGVmYXVsdDogbW9kdWxlLkZvcmdvdFBhc3N3b3JkIH0pKSk7XG5jb25zdCBSZXNldFBhc3N3b3JkID0gbGF6eSgoKSA9PiBpbXBvcnQoJy4vcGFnZXMvYXV0aC9SZXNldFBhc3N3b3JkJykudGhlbihtb2R1bGUgPT4gKHsgZGVmYXVsdDogbW9kdWxlLlJlc2V0UGFzc3dvcmQgfSkpKTtcblxuY29uc3QgTG9hZGluZ0ZhbGxiYWNrID0gKCkgPT4gKFxuICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbCB3LWZ1bGwgbWluLWgtc2NyZWVuXCI+XG4gICAgPExvYWRlcjIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHRleHQtYnJhbmQtNTAwXCIgc2l6ZT17NDB9IC8+XG4gIDwvZGl2PlxuKTtcblxuLy8gV3JhcHBlciBwYXJhIFJ1dGFzIFByaXZhZGFzIChSZXF1aWVyZSBMb2dpbilcbmNvbnN0IFByb3RlY3RlZFJvdXRlID0gKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pID0+IHtcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQsIGlzTG9hZGluZyB9ID0gdXNlQXV0aCgpO1xuICBcbiAgaWYgKGlzTG9hZGluZykgcmV0dXJuIDxMb2FkaW5nRmFsbGJhY2sgLz47XG4gIGlmICghaXNBdXRoZW50aWNhdGVkKSByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSAvPjtcbiAgXG4gIHJldHVybiA8PntjaGlsZHJlbn08Lz47XG59O1xuXG4vLyBXcmFwcGVyIHBhcmEgUnV0YXMgUMO6YmxpY2FzIChTaSB5YSBlc3TDoXMgbG9ndWVhZG8sIHRlIG1hbmRhIGFsIERhc2hib2FyZClcbmNvbnN0IFB1YmxpY1JvdXRlID0gKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pID0+IHtcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQsIGlzTG9hZGluZyB9ID0gdXNlQXV0aCgpO1xuICBcbiAgaWYgKGlzTG9hZGluZykgcmV0dXJuIDxMb2FkaW5nRmFsbGJhY2sgLz47XG4gIGlmIChpc0F1dGhlbnRpY2F0ZWQpIHJldHVybiA8TmF2aWdhdGUgdG89XCIvXCIgcmVwbGFjZSAvPjtcbiAgXG4gIHJldHVybiA8PntjaGlsZHJlbn08Lz47XG59O1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPEF1dGhQcm92aWRlcj5cbiAgICAgIDxCcm93c2VyUm91dGVyPlxuICAgICAgICA8Um91dGVzPlxuICAgICAgICAgIHsvKiBSVVRBUyBQw5pCTElDQVMgKEF1dGgpICovfVxuICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHVibGljUm91dGU+PEF1dGhMYXlvdXQgLz48L1B1YmxpY1JvdXRlPn0+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxMb2FkaW5nRmFsbGJhY2sgLz59PlxuICAgICAgICAgICAgICAgIDxMb2dpbiAvPlxuICAgICAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICAgICAgfSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVnaXN0ZXJcIiBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8TG9hZGluZ0ZhbGxiYWNrIC8+fT5cbiAgICAgICAgICAgICAgICA8UmVnaXN0ZXIgLz5cbiAgICAgICAgICAgICAgPC9TdXNwZW5zZT5cbiAgICAgICAgICAgIH0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2ZvcmdvdC1wYXNzd29yZFwiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxMb2FkaW5nRmFsbGJhY2sgLz59PlxuICAgICAgICAgICAgICAgIDxGb3Jnb3RQYXNzd29yZCAvPlxuICAgICAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICAgICAgfSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVzZXQtcGFzc3dvcmRcIiBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8TG9hZGluZ0ZhbGxiYWNrIC8+fT5cbiAgICAgICAgICAgICAgICA8UmVzZXRQYXNzd29yZCAvPlxuICAgICAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICAgICAgfSAvPlxuICAgICAgICAgIDwvUm91dGU+XG5cbiAgICAgICAgICB7LyogUlVUQVMgUFJJVkFEQVMgKERhc2hib2FyZCkgKi99XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PFByb3RlY3RlZFJvdXRlPjxBcHBMYXlvdXQgLz48L1Byb3RlY3RlZFJvdXRlPn0+XG4gICAgICAgICAgICA8Um91dGUgaW5kZXggZWxlbWVudD17XG4gICAgICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PExvYWRpbmdGYWxsYmFjayAvPn0+XG4gICAgICAgICAgICAgICAgPERhc2hib2FyZCAvPlxuICAgICAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICAgICAgfSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJjYWxlbmRhclwiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxMb2FkaW5nRmFsbGJhY2sgLz59PlxuICAgICAgICAgICAgICAgIDxDYWxlbmRhciAvPlxuICAgICAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICAgICAgfSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJjb21wb3NlXCIgZWxlbWVudD17XG4gICAgICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PExvYWRpbmdGYWxsYmFjayAvPn0+XG4gICAgICAgICAgICAgICAgPENvbXBvc2VyIC8+XG4gICAgICAgICAgICAgIDwvU3VzcGVuc2U+XG4gICAgICAgICAgICB9IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cImNhbXBhaWduc1wiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxMb2FkaW5nRmFsbGJhY2sgLz59PlxuICAgICAgICAgICAgICAgIDxDYW1wYWlnbnMgLz5cbiAgICAgICAgICAgICAgPC9TdXNwZW5zZT5cbiAgICAgICAgICAgIH0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwic2V0dGluZ3NcIiBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8TG9hZGluZ0ZhbGxiYWNrIC8+fT5cbiAgICAgICAgICAgICAgICA8U2V0dGluZ3MgLz5cbiAgICAgICAgICAgICAgPC9TdXNwZW5zZT5cbiAgICAgICAgICAgIH0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiYmlsbGluZ1wiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxMb2FkaW5nRmFsbGJhY2sgLz59PlxuICAgICAgICAgICAgICAgIDxCaWxsaW5nIC8+XG4gICAgICAgICAgICAgIDwvU3VzcGVuc2U+XG4gICAgICAgICAgICB9IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cImNhbGxiYWNrL2ZhY2Vib29rXCIgZWxlbWVudD17XG4gICAgICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PExvYWRpbmdGYWxsYmFjayAvPn0+XG4gICAgICAgICAgICAgICAgPEZhY2Vib29rQ2FsbGJhY2sgLz5cbiAgICAgICAgICAgICAgPC9TdXNwZW5zZT5cbiAgICAgICAgICAgIH0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiY2FsbGJhY2svbGlua2VkaW5cIiBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8TG9hZGluZ0ZhbGxiYWNrIC8+fT5cbiAgICAgICAgICAgICAgICA8TGlua2VkSW5DYWxsYmFjayAvPlxuICAgICAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICAgICAgfSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJjYWxsYmFjay90aWt0b2tcIiBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8TG9hZGluZ0ZhbGxiYWNrIC8+fT5cbiAgICAgICAgICAgICAgICA8VGlrVG9rQ2FsbGJhY2sgLz5cbiAgICAgICAgICAgICAgPC9TdXNwZW5zZT5cbiAgICAgICAgICAgIH0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwic3VwZXJhZG1pblwiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxMb2FkaW5nRmFsbGJhY2sgLz59PlxuICAgICAgICAgICAgICAgIDxTdXBlckFkbWluIC8+XG4gICAgICAgICAgICAgIDwvU3VzcGVuc2U+XG4gICAgICAgICAgICB9IC8+XG4gICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgPC9Sb3V0ZXM+XG4gICAgICA8L0Jyb3dzZXJSb3V0ZXI+XG4gICAgPC9BdXRoUHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdfQ==