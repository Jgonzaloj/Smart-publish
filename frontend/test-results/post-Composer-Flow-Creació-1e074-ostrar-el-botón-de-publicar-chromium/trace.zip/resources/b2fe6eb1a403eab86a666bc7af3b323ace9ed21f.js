import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Composer.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03b8b458";
import { Image, Wand2, Send, Loader2, Smile, Hash, Heart, MessageCircle, Share2, Bookmark } from "/node_modules/.vite/deps/lucide-react.js?v=03b8b458";
import { api } from "/src/lib/api.ts";
var _jsxFileName = "C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/Composer.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03b8b458";
var _s = $RefreshSig$();
export const Composer = () => {
	_s();
	const [content, setContent] = useState("");
	const [topic, setTopic] = useState("");
	const [isGenerating, setIsGenerating] = useState(false);
	const [isPublishing, setIsPublishing] = useState(false);
	const [platform, setPlatform] = useState("FACEBOOK");
	const [isScheduled, setIsScheduled] = useState(false);
	const [scheduleDate, setScheduleDate] = useState("");
	const [scheduleTime, setScheduleTime] = useState("");
	const [imageFile, setImageFile] = useState(null);
	const [imagePreview, setImagePreview] = useState(null);
	const fileInputRef = React.useRef(null);
	const [accounts, setAccounts] = useState([]);
	const [selectedAccountId, setSelectedAccountId] = useState("");
	useEffect(() => {
		api.get("/system/status").then((res) => {
			if (res.data.success && res.data.data.accounts) {
				setAccounts(res.data.data.accounts);
			}
		}).catch(console.error);
	}, []);
	const handleImageChange = (e) => {
		if (e.target.files && e.target.files[0]) {
			const file = e.target.files[0];
			setImageFile(file);
			setImagePreview(URL.createObjectURL(file));
		}
	};
	const handleGenerateAI = async () => {
		if (!topic) return alert("Ingresa un tema primero");
		setIsGenerating(true);
		try {
			const response = await api.post("/ai/suggest", { topic });
			if (response.data.success) {
				setContent(response.data.data);
			}
		} catch (error) {
			console.error(error);
			alert("Error generando contenido");
		} finally {
			setIsGenerating(false);
		}
	};
	const handlePublish = async () => {
		if (!content) return alert("El contenido no puede estar vacío");
		if (platform === "INSTAGRAM" && !imageFile) {
			return alert("Instagram requiere obligatoriamente una imagen para publicar.");
		}
		setIsPublishing(true);
		try {
			const formData = new FormData();
			formData.append("workspaceId", "ws-1");
			formData.append("platform", platform);
			formData.append("message", content);
			if (selectedAccountId) {
				formData.append("accountId", selectedAccountId);
			}
			if (imageFile) {
				formData.append("image", imageFile);
			}
			if (isScheduled) {
				if (!scheduleDate || !scheduleTime) {
					setIsPublishing(false);
					return alert("Por favor selecciona una fecha y hora para programar.");
				}
				const scheduledAt = new Date(`${scheduleDate}T${scheduleTime}`).toISOString();
				formData.append("scheduledAt", scheduledAt);
			}
			const response = await api.post("/automation/schedule", formData, { headers: { "Content-Type": "multipart/form-data" } });
			if (response.data.success) {
				alert("¡Publicación encolada/enviada con éxito!");
				setContent("");
				setImageFile(null);
				setImagePreview(null);
			}
		} catch (error) {
			console.error(error);
			alert(error.response?.data?.message || "Error al publicar. Verifica tu sesión o consola.");
		} finally {
			setIsPublishing(false);
		}
	};
	const maxChars = platform === "INSTAGRAM" ? 2200 : 63206;
	const progressPercentage = Math.min(content.length / maxChars * 100, 100);
	const selectedAccountName = accounts.find((a) => a.id === selectedAccountId)?.account_name || "Tu Cuenta Profesional";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "grid grid-cols-1 xl:grid-cols-12 gap-8 h-full max-w-7xl mx-auto pb-10",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "xl:col-span-7 flex flex-col gap-6",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-3xl font-bold tracking-tight",
					children: "Creador de Posts"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 mt-1",
					children: "Crea, previsualiza y programa contenido en múltiples plataformas."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex bg-slate-100 dark:bg-slate-800/50 p-1.5 rounded-2xl w-max",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setPlatform("FACEBOOK"),
						className: `flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-all ${platform === "FACEBOOK" ? "bg-white dark:bg-slate-700 text-[#1877F2] shadow-sm" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
						children: "Facebook"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setPlatform("INSTAGRAM"),
						className: `flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-all ${platform === "INSTAGRAM" ? "bg-white dark:bg-slate-700 text-pink-600 shadow-sm" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"}`,
						children: "Instagram"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "glass-panel p-6 sm:p-8 flex flex-col gap-6 relative overflow-hidden",
					children: [
						platform === "INSTAGRAM" && /* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-pink-500/10 via-purple-500/10 to-yellow-500/10 blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 13
						}, this),
						platform === "FACEBOOK" && /* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 right-0 w-64 h-64 bg-blue-500/10 blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 13
						}, this),
						accounts.filter((a) => a.platform === platform).length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-2 relative z-10",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-sm font-bold text-slate-700 dark:text-slate-300",
								children: "Publicar como"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								className: "input-field bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 shadow-sm focus:ring-brand-500/20",
								value: selectedAccountId,
								onChange: (e) => setSelectedAccountId(e.target.value),
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "",
									children: "-- Usar cuenta por defecto --"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 17
								}, this), accounts.filter((a) => a.platform === platform).map((acc) => /* @__PURE__ */ _jsxDEV("option", {
									value: acc.id,
									children: acc.account_name
								}, acc.id, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 19
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-2 relative z-10",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-sm font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Wand2, {
									size: 16,
									className: "text-brand-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 15
								}, this), " Piloto IA Mágico"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2 group",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "Ej: Anuncia nuestro nuevo menú de verano con emojis...",
									className: "input-field bg-white dark:bg-slate-900 shadow-sm transition-all focus:ring-brand-500/20",
									value: topic,
									onChange: (e) => setTopic(e.target.value),
									onKeyDown: (e) => e.key === "Enter" && handleGenerateAI()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleGenerateAI,
									disabled: isGenerating || !topic,
									className: "btn-primary whitespace-nowrap shadow-brand-500/20 disabled:opacity-50",
									children: isGenerating ? /* @__PURE__ */ _jsxDEV(Loader2, {
										className: "animate-spin",
										size: 20
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 33
									}, this) : "Escribir por mí"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 171,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col relative z-10",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "relative group",
								children: [/* @__PURE__ */ _jsxDEV("textarea", {
									className: "input-field min-h-[220px] resize-none bg-white dark:bg-slate-900 shadow-inner p-4 text-base leading-relaxed rounded-b-none focus:ring-0 focus:border-slate-300 dark:focus:border-slate-600 border-b-0",
									placeholder: "¿Qué quieres compartir hoy con tu audiencia?...",
									value: content,
									onChange: (e) => setContent(e.target.value),
									maxLength: maxChars
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 184,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "h-1 w-full bg-slate-100 dark:bg-slate-800",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: `h-full transition-all duration-300 ${progressPercentage > 90 ? "bg-red-500" : progressPercentage > 75 ? "bg-amber-500" : "bg-emerald-500"}`,
										style: { width: `${progressPercentage}%` }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 192,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900/50 rounded-b-xl border border-t-0 border-slate-200 dark:border-slate-700",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => fileInputRef.current?.click(),
											className: `p-2 rounded-lg transition-colors flex items-center gap-2 text-sm font-medium ${platform === "INSTAGRAM" && !imageFile ? "text-pink-600 bg-pink-100 dark:bg-pink-900/30" : "text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800"}`,
											children: [/* @__PURE__ */ _jsxDEV(Image, { size: 18 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 207,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "hidden sm:inline",
												children: "Multimedia"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 208,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 203,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											className: "p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors",
											title: "Emojis (Proximamente)",
											children: /* @__PURE__ */ _jsxDEV(Smile, { size: 18 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 211,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 210,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											className: "p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors",
											title: "Hashtags (Proximamente)",
											children: /* @__PURE__ */ _jsxDEV(Hash, { size: 18 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 214,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 213,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "file",
											accept: "image/*",
											ref: fileInputRef,
											className: "hidden",
											onChange: handleImageChange
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 216,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: `text-xs font-medium ${progressPercentage > 90 ? "text-red-500" : "text-slate-400"}`,
									children: [
										content.length.toLocaleString(),
										" / ",
										maxChars.toLocaleString()
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 224,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 201,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-50 dark:bg-slate-800/30 rounded-xl p-4 border border-slate-200 dark:border-slate-700 relative z-10",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: /* @__PURE__ */ _jsxDEV("label", {
									className: "flex items-center gap-3 cursor-pointer group",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: `w-10 h-6 rounded-full transition-colors relative flex items-center ${isScheduled ? "bg-brand-500" : "bg-slate-300 dark:bg-slate-600"}`,
											children: /* @__PURE__ */ _jsxDEV("div", { className: `w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform duration-200 absolute left-1 ${isScheduled ? "translate-x-4" : "translate-x-0"}` }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 235,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 234,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "checkbox",
											checked: isScheduled,
											onChange: (e) => setIsScheduled(e.target.checked),
											className: "hidden"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 237,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm font-bold text-slate-700 dark:text-slate-300 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors",
											children: "Programar para más tarde"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 243,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: `grid grid-cols-2 gap-4 transition-all duration-300 overflow-hidden ${isScheduled ? "mt-4 opacity-100 max-h-40" : "max-h-0 opacity-0"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-bold text-slate-500 uppercase tracking-wider",
										children: "Fecha"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 251,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "date",
										value: scheduleDate,
										onChange: (e) => setScheduleDate(e.target.value),
										className: "input-field bg-white dark:bg-slate-900",
										min: new Date().toISOString().split("T")[0]
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 252,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-xs font-bold text-slate-500 uppercase tracking-wider",
										children: "Hora"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 261,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "time",
										value: scheduleTime,
										onChange: (e) => setScheduleTime(e.target.value),
										className: "input-field bg-white dark:bg-slate-900"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 262,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-4 flex justify-end relative z-10 border-t border-slate-100 dark:border-slate-800",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: handlePublish,
								disabled: isPublishing,
								className: `btn-primary px-8 py-3 text-base shadow-xl ${isScheduled ? "bg-brand-600 hover:bg-brand-700 shadow-brand-600/30" : platform === "INSTAGRAM" ? "bg-gradient-to-r from-purple-500 to-pink-500 shadow-pink-500/30" : "bg-[#1877F2] shadow-blue-500/30"}`,
								children: [isPublishing ? /* @__PURE__ */ _jsxDEV(Loader2, {
									className: "animate-spin",
									size: 20
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 31
								}, this) : /* @__PURE__ */ _jsxDEV(Send, { size: 20 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 80
								}, this), isScheduled ? "Dejar Programado" : "Publicar Ahora"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 274,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "hidden xl:flex flex-col gap-6 xl:col-span-5 sticky top-6",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-lg font-bold text-slate-400 dark:text-slate-500 flex items-center gap-2",
				children: "Vista Previa en Vivo"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 290,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-slate-400 mt-1",
				children: "Así es como lo verá tu audiencia."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 293,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 289,
				columnNumber: 9
			}, this), platform === "FACEBOOK" ? /* @__PURE__ */ _jsxDEV(
				"div",
				/* MOCKUP FACEBOOK */
				{
					className: "bg-white dark:bg-[#242526] rounded-xl shadow-lg border border-slate-200 dark:border-slate-700/50 overflow-hidden w-full max-w-md mx-auto transition-all",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-[#1877F2] text-xl shrink-0 overflow-hidden",
									children: /* @__PURE__ */ _jsxDEV("img", {
										src: "https://ui-avatars.com/api/?name=SP&background=e2e8f0&color=1877f2",
										alt: "Avatar",
										className: "w-full h-full object-cover"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 303,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 302,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-bold text-[15px] text-[#050505] dark:text-[#E4E6EB] leading-tight hover:underline cursor-pointer",
									children: selectedAccountName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[13px] text-[#65676B] dark:text-[#B0B3B8] flex items-center gap-1",
									children: ["Justo ahora · ", /* @__PURE__ */ _jsxDEV("span", {
										className: "w-3 h-3 bg-slate-400 mask mask-globe",
										children: "🌎"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 35
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center text-slate-500 cursor-pointer text-xl font-bold pb-2",
									children: "..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 313,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-4 pb-3 text-[15px] text-[#050505] dark:text-[#E4E6EB] whitespace-pre-wrap break-words font-normal",
							children: content || /* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 italic",
								children: "Escribe algo para ver cómo queda..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 27
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 13
						}, this),
						imagePreview && /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full bg-slate-100 dark:bg-black overflow-hidden border-y border-slate-200 dark:border-slate-800",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: imagePreview,
								alt: "Preview",
								className: "w-full max-h-[500px] object-contain"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-4 py-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between py-2 border-b border-slate-200 dark:border-slate-700/50 text-[13px] text-[#65676B] dark:text-[#B0B3B8]",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-5 h-5 rounded-full bg-[#1877F2] flex items-center justify-center text-white text-xs p-1",
											children: "👍"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 333,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-5 h-5 rounded-full bg-red-500 flex items-center justify-center text-white text-xs p-1 -ml-1 border-2 border-white dark:border-[#242526]",
											children: "❤️"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 334,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "ml-1",
											children: "Tú y 42 más"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 335,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 332,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: "12 comentarios" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 337,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between pt-1",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										className: "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 text-[#65676B] dark:text-[#B0B3B8] font-semibold text-[15px] transition-colors",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl",
											children: "👍"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 341,
											columnNumber: 19
										}, this), " Me gusta"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 340,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 text-[#65676B] dark:text-[#B0B3B8] font-semibold text-[15px] transition-colors",
										children: [/* @__PURE__ */ _jsxDEV(MessageCircle, { size: 20 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 19
										}, this), " Comentar"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 text-[#65676B] dark:text-[#B0B3B8] font-semibold text-[15px] transition-colors",
										children: [/* @__PURE__ */ _jsxDEV(Share2, { size: 20 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 347,
											columnNumber: 19
										}, this), " Compartir"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 346,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 330,
							columnNumber: 13
						}, this)
					]
				},
				void 0,
				true,
				{
					fileName: _jsxFileName,
					lineNumber: 298,
					columnNumber: 11
				},
				this
			) : 
			/* MOCKUP INSTAGRAM */
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-black rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden w-full max-w-[400px] mx-auto shadow-2xl transition-all",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-9 h-9 rounded-full p-[2px] bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-500",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "w-full h-full bg-white dark:bg-black rounded-full border border-white dark:border-black p-0.5",
									children: /* @__PURE__ */ _jsxDEV("img", {
										src: "https://ui-avatars.com/api/?name=IG&background=000&color=fff",
										alt: "Avatar",
										className: "w-full h-full rounded-full object-cover"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 360,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 359,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 358,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "font-semibold text-sm text-black dark:text-white leading-tight",
								children: selectedAccountName.replace(/\s+/g, "").toLowerCase()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 364,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-black dark:text-white opacity-60",
								children: "Sponsored"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 365,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex gap-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { className: "w-1 h-1 bg-black dark:bg-white rounded-full" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 369,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "w-1 h-1 bg-black dark:bg-white rounded-full" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 370,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "w-1 h-1 bg-black dark:bg-white rounded-full" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 371,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 368,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 356,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-full aspect-square bg-slate-100 dark:bg-slate-900 flex items-center justify-center overflow-hidden border-y border-slate-100 dark:border-slate-800 relative group",
						children: [imagePreview ? /* @__PURE__ */ _jsxDEV("img", {
							src: imagePreview,
							alt: "Preview",
							className: "w-full h-full object-cover"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 378,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "text-slate-400 flex flex-col items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Image, {
								size: 48,
								className: "opacity-50"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 381,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm font-medium",
								children: "Requiere imagen obligatoria"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 380,
							columnNumber: 17
						}, this), imagePreview && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute bottom-4 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { className: "w-1.5 h-1.5 rounded-full bg-blue-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 388,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "w-1.5 h-1.5 rounded-full bg-white/50" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 389,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "w-1.5 h-1.5 rounded-full bg-white/50" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 387,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 376,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "px-3 pt-3 pb-1 flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex gap-4 items-center text-black dark:text-white",
							children: [
								/* @__PURE__ */ _jsxDEV(Heart, {
									size: 24,
									className: "hover:text-red-500 transition-colors cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 398,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(MessageCircle, {
									size: 24,
									className: "cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 399,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(Share2, {
									size: 24,
									className: "cursor-pointer -rotate-45 mb-1"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 400,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 397,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(Bookmark, {
							size: 24,
							className: "text-black dark:text-white cursor-pointer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 402,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 396,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "px-3 pb-4",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm font-semibold text-black dark:text-white mb-1",
								children: "1,342 Me gusta"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 407,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-sm text-black dark:text-white leading-relaxed",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold mr-2",
									children: selectedAccountName.replace(/\s+/g, "").toLowerCase()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 17
								}, this), content ? /* @__PURE__ */ _jsxDEV("span", {
									className: "whitespace-pre-wrap",
									children: content
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 italic font-normal",
									children: "La descripción de tu foto aparecerá aquí..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 413,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 408,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[10px] text-slate-500 uppercase mt-2 font-medium tracking-wider",
								children: "Hace 2 horas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 416,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 406,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 354,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 288,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 107,
		columnNumber: 5
	}, this);
};
_s(Composer, "9I4i0ZWjh2a2H2rs1aQZ0CROB3E=");
_c = Composer;
var _c;
$RefreshReg$(_c, "Composer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Composer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/Composer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/Composer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Admin/Desktop/smart-publish/frontend/src/pages/Composer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsT0FBTyxPQUFPLE1BQU0sU0FBUyxPQUFPLE1BQU0sT0FBTyxlQUFlLFFBQVEsZ0JBQWdCO0FBQ2pHLFNBQVMsV0FBVzs7OztBQUVwQixPQUFPLE1BQU0saUJBQWlCOztDQUM1QixNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFtQyxVQUFVO0NBQzdFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsRUFBRTtDQUNuRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBRW5ELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFzQixJQUFJO0NBQzVELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUF3QixJQUFJO0NBQ3BFLE1BQU0sZUFBZSxNQUFNLE9BQXlCLElBQUk7Q0FFeEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFnQixDQUFDLENBQUM7Q0FDbEQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBaUIsRUFBRTtDQUVyRSxnQkFBZ0I7RUFDZCxJQUFJLElBQUksZ0JBQWdCLENBQUMsQ0FBQyxNQUFLLFFBQU87R0FDcEMsSUFBSSxJQUFJLEtBQUssV0FBVyxJQUFJLEtBQUssS0FBSyxVQUFVO0lBQzlDLFlBQVksSUFBSSxLQUFLLEtBQUssUUFBUTtHQUNwQztFQUNGLENBQUMsQ0FBQyxDQUFDLE1BQU0sUUFBUSxLQUFLO0NBQ3hCLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxxQkFBcUIsTUFBMkM7RUFDcEUsSUFBSSxFQUFFLE9BQU8sU0FBUyxFQUFFLE9BQU8sTUFBTSxJQUFJO0dBQ3ZDLE1BQU0sT0FBTyxFQUFFLE9BQU8sTUFBTTtHQUM1QixhQUFhLElBQUk7R0FDakIsZ0JBQWdCLElBQUksZ0JBQWdCLElBQUksQ0FBQztFQUMzQztDQUNGO0NBRUEsTUFBTSxtQkFBbUIsWUFBWTtFQUNuQyxJQUFJLENBQUMsT0FBTyxPQUFPLE1BQU0seUJBQXlCO0VBQ2xELGdCQUFnQixJQUFJO0VBQ3BCLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQztHQUN4RCxJQUFJLFNBQVMsS0FBSyxTQUFTO0lBQ3pCLFdBQVcsU0FBUyxLQUFLLElBQUk7R0FDL0I7RUFDRixTQUFTLE9BQU87R0FDZCxRQUFRLE1BQU0sS0FBSztHQUNuQixNQUFNLDJCQUEyQjtFQUNuQyxVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjtDQUVBLE1BQU0sZ0JBQWdCLFlBQVk7RUFDaEMsSUFBSSxDQUFDLFNBQVMsT0FBTyxNQUFNLG1DQUFtQztFQUM5RCxJQUFJLGFBQWEsZUFBZSxDQUFDLFdBQVc7R0FDeEMsT0FBTyxNQUFNLCtEQUErRDtFQUNoRjtFQUVBLGdCQUFnQixJQUFJO0VBQ3BCLElBQUk7R0FDRixNQUFNLFdBQVcsSUFBSSxTQUFTO0dBQzlCLFNBQVMsT0FBTyxlQUFlLE1BQU07R0FDckMsU0FBUyxPQUFPLFlBQVksUUFBUTtHQUNwQyxTQUFTLE9BQU8sV0FBVyxPQUFPO0dBRWxDLElBQUksbUJBQW1CO0lBQ25CLFNBQVMsT0FBTyxhQUFhLGlCQUFpQjtHQUNsRDtHQUVBLElBQUksV0FBVztJQUNYLFNBQVMsT0FBTyxTQUFTLFNBQVM7R0FDdEM7R0FFQSxJQUFJLGFBQWE7SUFDYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYztLQUNoQyxnQkFBZ0IsS0FBSztLQUNyQixPQUFPLE1BQU0sdURBQXVEO0lBQ3hFO0lBQ0EsTUFBTSxjQUFjLElBQUksS0FBSyxHQUFHLGFBQWEsR0FBRyxjQUFjLENBQUMsQ0FBQyxZQUFZO0lBQzVFLFNBQVMsT0FBTyxlQUFlLFdBQVc7R0FDOUM7R0FFQSxNQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssd0JBQXdCLFVBQVUsRUFDaEUsU0FBUyxFQUFFLGdCQUFnQixzQkFBc0IsRUFDbkQsQ0FBQztHQUNELElBQUksU0FBUyxLQUFLLFNBQVM7SUFDekIsTUFBTSwwQ0FBMEM7SUFDaEQsV0FBVyxFQUFFO0lBQ2IsYUFBYSxJQUFJO0lBQ2pCLGdCQUFnQixJQUFJO0dBQ3RCO0VBQ0YsU0FBUyxPQUFZO0dBQ25CLFFBQVEsTUFBTSxLQUFLO0dBQ25CLE1BQU0sTUFBTSxVQUFVLE1BQU0sV0FBVyxrREFBa0Q7RUFDM0YsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7Q0FFQSxNQUFNLFdBQVcsYUFBYSxjQUFjLE9BQU87Q0FDbkQsTUFBTSxxQkFBcUIsS0FBSyxJQUFLLFFBQVEsU0FBUyxXQUFZLEtBQUssR0FBRztDQUUxRSxNQUFNLHNCQUFzQixTQUFTLE1BQUssTUFBSyxFQUFFLE9BQU8saUJBQWlCLENBQUMsRUFBRSxnQkFBZ0I7Q0FFNUYsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBR0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvQztJQUFvQjs7OztjQUN0RSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFzQjtJQUFvRTs7OztZQUNwRzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsVUFBRDtNQUNJLGVBQWUsWUFBWSxVQUFVO01BQ3JDLFdBQVcsMkVBQTJFLGFBQWEsYUFBYSx3REFBd0Q7Z0JBQzNLO0tBRU87Ozs7ZUFDUix3QkFBQyxVQUFEO01BQ0ksZUFBZSxZQUFZLFdBQVc7TUFDdEMsV0FBVywyRUFBMkUsYUFBYSxjQUFjLHVEQUF1RDtnQkFDM0s7S0FFTzs7OzthQUNQOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0csYUFBYSxlQUNaLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVLQUE0Szs7Ozs7TUFFNUwsYUFBYSxjQUNaLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGdIQUFxSDs7Ozs7TUFJckksU0FBUyxRQUFPLE1BQUssRUFBRSxhQUFhLFFBQVEsQ0FBQyxDQUFDLFNBQVMsS0FDdEQsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBdUQ7T0FBb0I7Ozs7aUJBQzVGLHdCQUFDLFVBQUQ7UUFDRSxXQUFVO1FBQ1YsT0FBTztRQUNQLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7a0JBSHRELENBS0Usd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQUc7UUFBcUM7Ozs7a0JBQ3JELFNBQVMsUUFBTyxNQUFLLEVBQUUsYUFBYSxRQUFRLENBQUMsQ0FBQyxLQUFJLFFBQ2pELHdCQUFDLFVBQUQ7U0FBcUIsT0FBTyxJQUFJO21CQUFLLElBQUk7UUFBcUIsR0FBakQsSUFBSTs7OztlQUE2QyxDQUMvRCxDQUNLOzs7OztlQUNMOzs7Ozs7TUFJUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUNFLHdCQUFDLE9BQUQ7U0FBTyxNQUFNO1NBQUksV0FBVTtRQUFrQjs7OztrQkFBQyxtQkFDekM7Ozs7O2lCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osV0FBVTtTQUNWLE9BQU87U0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztTQUN4QyxZQUFZLE1BQU0sRUFBRSxRQUFRLFdBQVcsaUJBQWlCO1FBQ3pEOzs7O2tCQUNELHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsVUFBVSxnQkFBZ0IsQ0FBQztTQUMzQixXQUFVO21CQUVULGVBQWUsd0JBQUMsU0FBRDtVQUFTLFdBQVU7VUFBZSxNQUFNO1NBQUs7Ozs7b0JBQUk7UUFDM0Q7Ozs7Z0JBQ0w7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxZQUFEO1NBQ0UsV0FBVTtTQUNWLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVyxNQUFNLFdBQVcsRUFBRSxPQUFPLEtBQUs7U0FDMUMsV0FBVztRQUNaOzs7O2tCQUVELHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE9BQUQ7VUFDRSxXQUFXLHNDQUFzQyxxQkFBcUIsS0FBSyxlQUFlLHFCQUFxQixLQUFLLGlCQUFpQjtVQUNySSxPQUFPLEVBQUUsT0FBTyxHQUFHLG1CQUFtQixHQUFHO1NBQ3JDOzs7OztRQUNIOzs7O2dCQUNGOzs7OztpQkFHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsVUFBRDtXQUNFLGVBQWUsYUFBYSxTQUFTLE1BQU07V0FDM0MsV0FBVyxnRkFBZ0YsYUFBYSxlQUFlLENBQUMsWUFBWSxrREFBa0Q7cUJBRnhMLENBSUUsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztxQkFDbEIsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW1CO1dBQWdCOzs7O21CQUM3Qzs7Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUFRLFdBQVU7V0FBa0gsT0FBTTtxQkFDeEksd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7Ozs7VUFDWjs7Ozs7VUFDUix3QkFBQyxVQUFEO1dBQVEsV0FBVTtXQUFrSCxPQUFNO3FCQUN4SSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztVQUNYOzs7OztVQUNSLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsUUFBTztXQUNQLEtBQUs7V0FDTCxXQUFVO1dBQ1YsVUFBVTtVQUNYOzs7OztTQUNFOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVyx1QkFBdUIscUJBQXFCLEtBQUssaUJBQWlCO21CQUFsRjtVQUNHLFFBQVEsT0FBTyxlQUFlO1VBQUU7VUFBSSxTQUFTLGVBQWU7U0FDMUQ7Ozs7O2dCQUNGOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFXLHNFQUFzRSxjQUFjLGlCQUFpQjtxQkFDbkgsd0JBQUMsT0FBRCxFQUFLLFdBQVcsdUdBQXVHLGNBQWMsa0JBQWtCLGtCQUF3Qjs7Ozs7VUFDNUs7Ozs7O1VBQ0wsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxTQUFTO1dBQ1QsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLE9BQU87V0FDaEQsV0FBVTtVQUNYOzs7OztVQUNELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFvSTtVQUU5STs7Ozs7U0FDRDs7Ozs7O09BQ0o7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVcsc0VBQXNFLGNBQWMsOEJBQThCO2tCQUFsSSxDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTREO1NBQVk7Ozs7bUJBQ3pGLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7VUFDL0MsV0FBVTtVQUNWLEtBQUssSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1NBQzFDOzs7O2lCQUNFOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUE0RDtTQUFXOzs7O21CQUN4Rix3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU87VUFDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1VBQy9DLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxTQUFTO1FBQ1QsVUFBVTtRQUNWLFdBQVcsNkNBQTZDLGNBQWMsd0RBQXlELGFBQWEsY0FBYyxvRUFBb0U7a0JBSGhPLENBS0csZUFBZSx3QkFBQyxTQUFEO1NBQVMsV0FBVTtTQUFlLE1BQU07UUFBSzs7OzttQkFBSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2tCQUNqRixjQUFjLHFCQUFxQixnQkFDOUI7Ozs7OztNQUNMOzs7OztLQUVGOzs7Ozs7R0FDRjs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQStFO0dBRXpGOzs7O2FBQ0osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBOEI7R0FBb0M7Ozs7V0FDNUU7Ozs7YUFFSixhQUFhLGFBRVo7SUFBQzs7SUFBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxPQUFEO1VBQUssS0FBSTtVQUFxRSxLQUFJO1VBQVMsV0FBVTtTQUE4Qjs7Ozs7UUFDaEk7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5RztRQUF1Qjs7OztrQkFDN0ksd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FBc0Ysa0JBQ3RFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1QztTQUFROzs7O2lCQUM1RTs7Ozs7Z0JBQ0E7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUF3SjtRQUFROzs7OztPQUM1Szs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixXQUFXLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF3QjtPQUF5Qzs7Ozs7TUFDMUY7Ozs7O01BR0osZ0JBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUFLLEtBQUs7UUFBYyxLQUFJO1FBQVUsV0FBVTtPQUF1Qzs7Ozs7TUFDcEY7Ozs7O01BSVAsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTRGO1VBQU87Ozs7O1VBQ2xILHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE0STtVQUFPOzs7OztVQUNsSyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBTztVQUFpQjs7Ozs7U0FDckM7Ozs7O2tCQUNMLHdCQUFDLE9BQUQsWUFBSyxpQkFBbUI7Ozs7Z0JBQ3JCOzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO29CQUFsQixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFVO1VBQVE7Ozs7b0JBQUMsV0FDN0I7Ozs7OztTQUNSLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO29CQUFsQixDQUNFLHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7b0JBQUMsV0FDckI7Ozs7OztTQUNSLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO29CQUFsQixDQUNFLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7b0JBQUMsWUFDZDs7Ozs7O1FBQ0w7Ozs7O2VBQ0Y7Ozs7OztLQUNGOzs7Ozs7Ozs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE9BQUQ7VUFBSyxLQUFJO1VBQStELEtBQUk7VUFBUyxXQUFVO1NBQTJDOzs7OztRQUN2STs7Ozs7T0FDRjs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWtFLG9CQUFvQixRQUFRLFFBQVEsRUFBRSxDQUFDLENBQUMsWUFBWTtPQUFLOzs7O2lCQUN4SSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBZ0Q7T0FBWTs7OztlQUN0RTs7OztlQUNGOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDhDQUFtRDs7Ozs7UUFDbEUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsOENBQW1EOzs7OztRQUNsRSx3QkFBQyxPQUFELEVBQUssV0FBVSw4Q0FBbUQ7Ozs7O09BQy9EOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNHLGVBQ0Msd0JBQUMsT0FBRDtPQUFLLEtBQUs7T0FBYyxLQUFJO09BQVUsV0FBVTtNQUE4Qjs7OztpQkFFOUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQU8sTUFBTTtRQUFJLFdBQVU7T0FBYzs7OztpQkFDekMsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQXNCO09BQThCOzs7O2VBQzlEOzs7OztnQkFHTixnQkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVDQUE0Qzs7Ozs7UUFDM0Qsd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUNBQTRDOzs7OztRQUMzRCx3QkFBQyxPQUFELEVBQUssV0FBVSx1Q0FBNEM7Ozs7O09BQ3hEOzs7OztjQUVKOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFPLE1BQU07U0FBSSxXQUFVO1FBQXVEOzs7OztRQUNsRix3QkFBQyxlQUFEO1NBQWUsTUFBTTtTQUFJLFdBQVU7UUFBa0I7Ozs7O1FBQ3JELHdCQUFDLFFBQUQ7U0FBUSxNQUFNO1NBQUksV0FBVTtRQUFrQzs7Ozs7T0FDM0Q7Ozs7O2dCQUNMLHdCQUFDLFVBQUQ7T0FBVSxNQUFNO09BQUksV0FBVTtNQUE2Qzs7OztjQUN4RTs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBd0Q7T0FBaUI7Ozs7O09BQ3RGLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXNCLG9CQUFvQixRQUFRLFFBQVEsRUFBRSxDQUFDLENBQUMsWUFBWTtRQUFROzs7O2tCQUNqRyxVQUNDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1QjtRQUFjOzs7O21CQUVyRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBb0M7UUFBaUQ7Ozs7Z0JBRXBHOzs7Ozs7T0FDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBdUU7T0FBZTs7Ozs7TUFDaEc7Ozs7OztJQUNGOzs7OztXQUdKOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDb21wb3Nlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBJbWFnZSwgV2FuZDIsIFNlbmQsIExvYWRlcjIsIFNtaWxlLCBIYXNoLCBIZWFydCwgTWVzc2FnZUNpcmNsZSwgU2hhcmUyLCBCb29rbWFyayB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBhcGkgfSBmcm9tICcuLi9saWIvYXBpJztcblxuZXhwb3J0IGNvbnN0IENvbXBvc2VyID0gKCkgPT4ge1xuICBjb25zdCBbY29udGVudCwgc2V0Q29udGVudF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt0b3BpYywgc2V0VG9waWNdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaXNHZW5lcmF0aW5nLCBzZXRJc0dlbmVyYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNQdWJsaXNoaW5nLCBzZXRJc1B1Ymxpc2hpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcGxhdGZvcm0sIHNldFBsYXRmb3JtXSA9IHVzZVN0YXRlPCdGQUNFQk9PSycgfCAnSU5TVEFHUkFNJz4oJ0ZBQ0VCT09LJyk7XG4gIGNvbnN0IFtpc1NjaGVkdWxlZCwgc2V0SXNTY2hlZHVsZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2NoZWR1bGVEYXRlLCBzZXRTY2hlZHVsZURhdGVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2NoZWR1bGVUaW1lLCBzZXRTY2hlZHVsZVRpbWVdID0gdXNlU3RhdGUoJycpO1xuICBcbiAgY29uc3QgW2ltYWdlRmlsZSwgc2V0SW1hZ2VGaWxlXSA9IHVzZVN0YXRlPEZpbGUgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2ltYWdlUHJldmlldywgc2V0SW1hZ2VQcmV2aWV3XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBmaWxlSW5wdXRSZWYgPSBSZWFjdC51c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG5cbiAgY29uc3QgW2FjY291bnRzLCBzZXRBY2NvdW50c10gPSB1c2VTdGF0ZTxhbnlbXT4oW10pO1xuICBjb25zdCBbc2VsZWN0ZWRBY2NvdW50SWQsIHNldFNlbGVjdGVkQWNjb3VudElkXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXBpLmdldCgnL3N5c3RlbS9zdGF0dXMnKS50aGVuKHJlcyA9PiB7XG4gICAgICBpZiAocmVzLmRhdGEuc3VjY2VzcyAmJiByZXMuZGF0YS5kYXRhLmFjY291bnRzKSB7XG4gICAgICAgIHNldEFjY291bnRzKHJlcy5kYXRhLmRhdGEuYWNjb3VudHMpO1xuICAgICAgfVxuICAgIH0pLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlSW1hZ2VDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBpZiAoZS50YXJnZXQuZmlsZXMgJiYgZS50YXJnZXQuZmlsZXNbMF0pIHtcbiAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcbiAgICAgIHNldEltYWdlRmlsZShmaWxlKTtcbiAgICAgIHNldEltYWdlUHJldmlldyhVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlR2VuZXJhdGVBSSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXRvcGljKSByZXR1cm4gYWxlcnQoJ0luZ3Jlc2EgdW4gdGVtYSBwcmltZXJvJyk7XG4gICAgc2V0SXNHZW5lcmF0aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KCcvYWkvc3VnZ2VzdCcsIHsgdG9waWMgfSk7XG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XG4gICAgICAgIHNldENvbnRlbnQocmVzcG9uc2UuZGF0YS5kYXRhKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICBhbGVydCgnRXJyb3IgZ2VuZXJhbmRvIGNvbnRlbmlkbycpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0dlbmVyYXRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVQdWJsaXNoID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghY29udGVudCkgcmV0dXJuIGFsZXJ0KCdFbCBjb250ZW5pZG8gbm8gcHVlZGUgZXN0YXIgdmFjw61vJyk7XG4gICAgaWYgKHBsYXRmb3JtID09PSAnSU5TVEFHUkFNJyAmJiAhaW1hZ2VGaWxlKSB7XG4gICAgICAgIHJldHVybiBhbGVydCgnSW5zdGFncmFtIHJlcXVpZXJlIG9ibGlnYXRvcmlhbWVudGUgdW5hIGltYWdlbiBwYXJhIHB1YmxpY2FyLicpO1xuICAgIH1cblxuICAgIHNldElzUHVibGlzaGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcbiAgICAgIGZvcm1EYXRhLmFwcGVuZCgnd29ya3NwYWNlSWQnLCAnd3MtMScpOyAvLyBNVlBcbiAgICAgIGZvcm1EYXRhLmFwcGVuZCgncGxhdGZvcm0nLCBwbGF0Zm9ybSk7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ21lc3NhZ2UnLCBjb250ZW50KTtcbiAgICAgIFxuICAgICAgaWYgKHNlbGVjdGVkQWNjb3VudElkKSB7XG4gICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdhY2NvdW50SWQnLCBzZWxlY3RlZEFjY291bnRJZCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGlmIChpbWFnZUZpbGUpIHtcbiAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ltYWdlJywgaW1hZ2VGaWxlKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGlzU2NoZWR1bGVkKSB7XG4gICAgICAgICAgaWYgKCFzY2hlZHVsZURhdGUgfHwgIXNjaGVkdWxlVGltZSkge1xuICAgICAgICAgICAgICBzZXRJc1B1Ymxpc2hpbmcoZmFsc2UpO1xuICAgICAgICAgICAgICByZXR1cm4gYWxlcnQoJ1BvciBmYXZvciBzZWxlY2Npb25hIHVuYSBmZWNoYSB5IGhvcmEgcGFyYSBwcm9ncmFtYXIuJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHNjaGVkdWxlZEF0ID0gbmV3IERhdGUoYCR7c2NoZWR1bGVEYXRlfVQke3NjaGVkdWxlVGltZX1gKS50b0lTT1N0cmluZygpO1xuICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnc2NoZWR1bGVkQXQnLCBzY2hlZHVsZWRBdCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoJy9hdXRvbWF0aW9uL3NjaGVkdWxlJywgZm9ybURhdGEsIHtcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ211bHRpcGFydC9mb3JtLWRhdGEnIH1cbiAgICAgIH0pO1xuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xuICAgICAgICBhbGVydCgnwqFQdWJsaWNhY2nDs24gZW5jb2xhZGEvZW52aWFkYSBjb24gw6l4aXRvIScpO1xuICAgICAgICBzZXRDb250ZW50KCcnKTtcbiAgICAgICAgc2V0SW1hZ2VGaWxlKG51bGwpO1xuICAgICAgICBzZXRJbWFnZVByZXZpZXcobnVsbCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICBhbGVydChlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCAnRXJyb3IgYWwgcHVibGljYXIuIFZlcmlmaWNhIHR1IHNlc2nDs24gbyBjb25zb2xhLicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1B1Ymxpc2hpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBtYXhDaGFycyA9IHBsYXRmb3JtID09PSAnSU5TVEFHUkFNJyA/IDIyMDAgOiA2MzIwNjtcbiAgY29uc3QgcHJvZ3Jlc3NQZXJjZW50YWdlID0gTWF0aC5taW4oKGNvbnRlbnQubGVuZ3RoIC8gbWF4Q2hhcnMpICogMTAwLCAxMDApO1xuICBcbiAgY29uc3Qgc2VsZWN0ZWRBY2NvdW50TmFtZSA9IGFjY291bnRzLmZpbmQoYSA9PiBhLmlkID09PSBzZWxlY3RlZEFjY291bnRJZCk/LmFjY291bnRfbmFtZSB8fCAnVHUgQ3VlbnRhIFByb2Zlc2lvbmFsJztcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSB4bDpncmlkLWNvbHMtMTIgZ2FwLTggaC1mdWxsIG1heC13LTd4bCBteC1hdXRvIHBiLTEwXCI+XG4gICAgICBcbiAgICAgIHsvKiBDb2x1bW5hIEl6cXVpZXJkYTogRWRpdG9yICg3IGNvbHVtbmFzKSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwieGw6Y29sLXNwYW4tNyBmbGV4IGZsZXgtY29sIGdhcC02XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodFwiPkNyZWFkb3IgZGUgUG9zdHM8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIG10LTFcIj5DcmVhLCBwcmV2aXN1YWxpemEgeSBwcm9ncmFtYSBjb250ZW5pZG8gZW4gbcO6bHRpcGxlcyBwbGF0YWZvcm1hcy48L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICBcbiAgICAgICAgey8qIFNlbGVjdG9yIGRlIFBsYXRhZm9ybWFzIE1vZGVybm8gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcC0xLjUgcm91bmRlZC0yeGwgdy1tYXhcIj5cbiAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGxhdGZvcm0oJ0ZBQ0VCT09LJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNiBweS0yLjUgcm91bmRlZC14bCBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtwbGF0Zm9ybSA9PT0gJ0ZBQ0VCT09LJyA/ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTcwMCB0ZXh0LVsjMTg3N0YyXSBzaGFkb3ctc20nIDogJ3RleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAnfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRmFjZWJvb2tcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQbGF0Zm9ybSgnSU5TVEFHUkFNJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNiBweS0yLjUgcm91bmRlZC14bCBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtwbGF0Zm9ybSA9PT0gJ0lOU1RBR1JBTScgPyAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1waW5rLTYwMCBzaGFkb3ctc20nIDogJ3RleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAnfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgSW5zdGFncmFtXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbGFzcy1wYW5lbCBwLTYgc206cC04IGZsZXggZmxleC1jb2wgZ2FwLTYgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAge3BsYXRmb3JtID09PSAnSU5TVEFHUkFNJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy02NCBoLTY0IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcGluay01MDAvMTAgdmlhLXB1cnBsZS01MDAvMTAgdG8teWVsbG93LTUwMC8xMCBibHVyLTN4bCAtdHJhbnNsYXRlLXktMS8yIHRyYW5zbGF0ZS14LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCI+PC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7cGxhdGZvcm0gPT09ICdGQUNFQk9PSycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctNjQgaC02NCBiZy1ibHVlLTUwMC8xMCBibHVyLTN4bCAtdHJhbnNsYXRlLXktMS8yIHRyYW5zbGF0ZS14LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCI+PC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBDdWVudGEgRGVzdGlubyAqL31cbiAgICAgICAgICB7YWNjb3VudHMuZmlsdGVyKGEgPT4gYS5wbGF0Zm9ybSA9PT0gcGxhdGZvcm0pLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5QdWJsaWNhciBjb21vPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdCBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dC1maWVsZCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctc20gZm9jdXM6cmluZy1icmFuZC01MDAvMjBcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEFjY291bnRJZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkQWNjb3VudElkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj4tLSBVc2FyIGN1ZW50YSBwb3IgZGVmZWN0byAtLTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIHthY2NvdW50cy5maWx0ZXIoYSA9PiBhLnBsYXRmb3JtID09PSBwbGF0Zm9ybSkubWFwKGFjYyA9PiAoXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YWNjLmlkfSB2YWx1ZT17YWNjLmlkfT57YWNjLmFjY291bnRfbmFtZX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIEFzaXN0ZW50ZSBJQSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgcmVsYXRpdmUgei0xMFwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPFdhbmQyIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWJyYW5kLTUwMFwiIC8+IFBpbG90byBJQSBNw6FnaWNvXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIGdyb3VwXCI+XG4gICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IEFudW5jaWEgbnVlc3RybyBudWV2byBtZW7DuiBkZSB2ZXJhbm8gY29uIGVtb2ppcy4uLlwiIFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbCBmb2N1czpyaW5nLWJyYW5kLTUwMC8yMFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RvcGljfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VG9waWMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IGUua2V5ID09PSAnRW50ZXInICYmIGhhbmRsZUdlbmVyYXRlQUkoKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVHZW5lcmF0ZUFJfSBcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNHZW5lcmF0aW5nIHx8ICF0b3BpY31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeSB3aGl0ZXNwYWNlLW5vd3JhcCBzaGFkb3ctYnJhbmQtNTAwLzIwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2lzR2VuZXJhdGluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIHNpemU9ezIwfSAvPiA6ICdFc2NyaWJpciBwb3IgbcOtJ31cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiDDgXJlYSBkZSBUZXh0byB5IENvbnRyb2xlcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgcmVsYXRpdmUgei0xMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxuICAgICAgICAgICAgICA8dGV4dGFyZWEgXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGQgbWluLWgtWzIyMHB4XSByZXNpemUtbm9uZSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBzaGFkb3ctaW5uZXIgcC00IHRleHQtYmFzZSBsZWFkaW5nLXJlbGF4ZWQgcm91bmRlZC1iLW5vbmUgZm9jdXM6cmluZy0wIGZvY3VzOmJvcmRlci1zbGF0ZS0zMDAgZGFyazpmb2N1czpib3JkZXItc2xhdGUtNjAwIGJvcmRlci1iLTBcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiwr9RdcOpIHF1aWVyZXMgY29tcGFydGlyIGhveSBjb24gdHUgYXVkaWVuY2lhPy4uLlwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NvbnRlbnR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb250ZW50KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9e21heENoYXJzfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICB7LyogQmFycmEgZGUgUHJvZ3Jlc28gZGUgQ2FyYWN0ZXJlcyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTEgdy1mdWxsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwICR7cHJvZ3Jlc3NQZXJjZW50YWdlID4gOTAgPyAnYmctcmVkLTUwMCcgOiBwcm9ncmVzc1BlcmNlbnRhZ2UgPiA3NSA/ICdiZy1hbWJlci01MDAnIDogJ2JnLWVtZXJhbGQtNTAwJ31gfVxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3Byb2dyZXNzUGVyY2VudGFnZX0lYCB9fVxuICAgICAgICAgICAgICAgID48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIFRvb2xiYXIgZGViYWpvIGRlbCB0ZXh0YXJlYSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTkwMC81MCByb3VuZGVkLWIteGwgYm9yZGVyIGJvcmRlci10LTAgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gJHtwbGF0Zm9ybSA9PT0gJ0lOU1RBR1JBTScgJiYgIWltYWdlRmlsZSA/ICd0ZXh0LXBpbmstNjAwIGJnLXBpbmstMTAwIGRhcms6YmctcGluay05MDAvMzAnIDogJ3RleHQtc2xhdGUtNTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCd9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8SW1hZ2Ugc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+TXVsdGltZWRpYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiIHRpdGxlPVwiRW1vamlzIChQcm94aW1hbWVudGUpXCI+XG4gICAgICAgICAgICAgICAgICA8U21pbGUgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnNcIiB0aXRsZT1cIkhhc2h0YWdzIChQcm94aW1hbWVudGUpXCI+XG4gICAgICAgICAgICAgICAgICA8SGFzaCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiIFxuICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiIFxuICAgICAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9IFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCIgXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW1hZ2VDaGFuZ2V9IFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHRleHQteHMgZm9udC1tZWRpdW0gJHtwcm9ncmVzc1BlcmNlbnRhZ2UgPiA5MCA/ICd0ZXh0LXJlZC01MDAnIDogJ3RleHQtc2xhdGUtNDAwJ31gfT5cbiAgICAgICAgICAgICAgICB7Y29udGVudC5sZW5ndGgudG9Mb2NhbGVTdHJpbmcoKX0gLyB7bWF4Q2hhcnMudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBQcm9ncmFtYWNpw7NuICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvMzAgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBjdXJzb3ItcG9pbnRlciBncm91cFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0xMCBoLTYgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tY29sb3JzIHJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyICR7aXNTY2hlZHVsZWQgPyAnYmctYnJhbmQtNTAwJyA6ICdiZy1zbGF0ZS0zMDAgZGFyazpiZy1zbGF0ZS02MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTQgaC00IGJnLXdoaXRlIHJvdW5kZWQtZnVsbCBzaGFkb3ctc20gdHJhbnNmb3JtIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMCBhYnNvbHV0ZSBsZWZ0LTEgJHtpc1NjaGVkdWxlZCA/ICd0cmFuc2xhdGUteC00JyA6ICd0cmFuc2xhdGUteC0wJ31gfT48L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIiBcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2NoZWR1bGVkfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJc1NjaGVkdWxlZChlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGdyb3VwLWhvdmVyOnRleHQtYnJhbmQtNjAwIGRhcms6Z3JvdXAtaG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIFByb2dyYW1hciBwYXJhIG3DoXMgdGFyZGVcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BncmlkIGdyaWQtY29scy0yIGdhcC00IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBvdmVyZmxvdy1oaWRkZW4gJHtpc1NjaGVkdWxlZCA/ICdtdC00IG9wYWNpdHktMTAwIG1heC1oLTQwJyA6ICdtYXgtaC0wIG9wYWNpdHktMCd9YH0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkZlY2hhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiIFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NjaGVkdWxlRGF0ZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2NoZWR1bGVEYXRlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0LWZpZWxkIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwXCJcbiAgICAgICAgICAgICAgICAgIG1pbj17bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkhvcmE8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0aW1lXCIgXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2NoZWR1bGVUaW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTY2hlZHVsZVRpbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtZmllbGQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDBcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQWNjacOzbiBQcmluY2lwYWwgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGZsZXgganVzdGlmeS1lbmQgcmVsYXRpdmUgei0xMCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHVibGlzaH1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHVibGlzaGluZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYnRuLXByaW1hcnkgcHgtOCBweS0zIHRleHQtYmFzZSBzaGFkb3cteGwgJHtpc1NjaGVkdWxlZCA/ICdiZy1icmFuZC02MDAgaG92ZXI6YmctYnJhbmQtNzAwIHNoYWRvdy1icmFuZC02MDAvMzAnIDogKHBsYXRmb3JtID09PSAnSU5TVEFHUkFNJyA/ICdiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTUwMCB0by1waW5rLTUwMCBzaGFkb3ctcGluay01MDAvMzAnIDogJ2JnLVsjMTg3N0YyXSBzaGFkb3ctYmx1ZS01MDAvMzAnKX1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7aXNQdWJsaXNoaW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgc2l6ZT17MjB9IC8+IDogPFNlbmQgc2l6ZT17MjB9IC8+fVxuICAgICAgICAgICAgICB7aXNTY2hlZHVsZWQgPyAnRGVqYXIgUHJvZ3JhbWFkbycgOiAnUHVibGljYXIgQWhvcmEnfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENvbHVtbmEgRGVyZWNoYTogVmlzdGEgUHJldmlhIFJlYWxpc3RhICg1IGNvbHVtbmFzKSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHhsOmZsZXggZmxleC1jb2wgZ2FwLTYgeGw6Y29sLXNwYW4tNSBzdGlja3kgdG9wLTZcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgVmlzdGEgUHJldmlhIGVuIFZpdm9cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS00MDAgbXQtMVwiPkFzw60gZXMgY29tbyBsbyB2ZXLDoSB0dSBhdWRpZW5jaWEuPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7cGxhdGZvcm0gPT09ICdGQUNFQk9PSycgPyAoXG4gICAgICAgICAgLyogTU9DS1VQIEZBQ0VCT09LICovXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMjQyNTI2XSByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAvNTAgb3ZlcmZsb3ctaGlkZGVuIHctZnVsbCBtYXgtdy1tZCBteC1hdXRvIHRyYW5zaXRpb24tYWxsXCI+XG4gICAgICAgICAgICB7LyogSGVhZGVyIEZCICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LVsjMTg3N0YyXSB0ZXh0LXhsIHNocmluay0wIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCJodHRwczovL3VpLWF2YXRhcnMuY29tL2FwaS8/bmFtZT1TUCZiYWNrZ3JvdW5kPWUyZThmMCZjb2xvcj0xODc3ZjJcIiBhbHQ9XCJBdmF0YXJcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LVsxNXB4XSB0ZXh0LVsjMDUwNTA1XSBkYXJrOnRleHQtWyNFNEU2RUJdIGxlYWRpbmctdGlnaHQgaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyXCI+e3NlbGVjdGVkQWNjb3VudE5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1bIzY1Njc2Ql0gZGFyazp0ZXh0LVsjQjBCM0I4XSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICBKdXN0byBhaG9yYSDCtyA8c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIGJnLXNsYXRlLTQwMCBtYXNrIG1hc2stZ2xvYmVcIj7wn4yOPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS01MDAgY3Vyc29yLXBvaW50ZXIgdGV4dC14bCBmb250LWJvbGQgcGItMlwiPi4uLjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogVGV4dG8gRkIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcGItMyB0ZXh0LVsxNXB4XSB0ZXh0LVsjMDUwNTA1XSBkYXJrOnRleHQtWyNFNEU2RUJdIHdoaXRlc3BhY2UtcHJlLXdyYXAgYnJlYWstd29yZHMgZm9udC1ub3JtYWxcIj5cbiAgICAgICAgICAgICAge2NvbnRlbnQgfHwgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaXRhbGljXCI+RXNjcmliZSBhbGdvIHBhcmEgdmVyIGPDs21vIHF1ZWRhLi4uPC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogSW1hZ2VuIEZCICovfVxuICAgICAgICAgICAge2ltYWdlUHJldmlldyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLWJsYWNrIG92ZXJmbG93LWhpZGRlbiBib3JkZXIteSBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtpbWFnZVByZXZpZXd9IGFsdD1cIlByZXZpZXdcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LWgtWzUwMHB4XSBvYmplY3QtY29udGFpblwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIEFjdGlvbnMgRkIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweS0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwLzUwIHRleHQtWzEzcHhdIHRleHQtWyM2NTY3NkJdIGRhcms6dGV4dC1bI0IwQjNCOF1cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZC1mdWxsIGJnLVsjMTg3N0YyXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIHRleHQteHMgcC0xXCI+8J+RjTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBiZy1yZWQtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgdGV4dC14cyBwLTEgLW1sLTEgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIGRhcms6Ym9yZGVyLVsjMjQyNTI2XVwiPuKdpO+4jzwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMVwiPlTDuiB5IDQyIG3DoXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj4xMiBjb21lbnRhcmlvczwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAvNTAgdGV4dC1bIzY1Njc2Ql0gZGFyazp0ZXh0LVsjQjBCM0I4XSBmb250LXNlbWlib2xkIHRleHQtWzE1cHhdIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsXCI+8J+RjTwvc3Bhbj4gTWUgZ3VzdGFcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweS0yIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwLzUwIHRleHQtWyM2NTY3NkJdIGRhcms6dGV4dC1bI0IwQjNCOF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsxNXB4XSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgc2l6ZT17MjB9IC8+IENvbWVudGFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMC81MCB0ZXh0LVsjNjU2NzZCXSBkYXJrOnRleHQtWyNCMEIzQjhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTVweF0gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIDxTaGFyZTIgc2l6ZT17MjB9IC8+IENvbXBhcnRpclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIC8qIE1PQ0tVUCBJTlNUQUdSQU0gKi9cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctYmxhY2sgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgb3ZlcmZsb3ctaGlkZGVuIHctZnVsbCBtYXgtdy1bNDAwcHhdIG14LWF1dG8gc2hhZG93LTJ4bCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgey8qIEhlYWRlciBJRyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBwLVsycHhdIGJnLWdyYWRpZW50LXRvLXRyIGZyb20teWVsbG93LTQwMCB2aWEtcGluay01MDAgdG8tcHVycGxlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIGJnLXdoaXRlIGRhcms6YmctYmxhY2sgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItd2hpdGUgZGFyazpib3JkZXItYmxhY2sgcC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCJodHRwczovL3VpLWF2YXRhcnMuY29tL2FwaS8/bmFtZT1JRyZiYWNrZ3JvdW5kPTAwMCZjb2xvcj1mZmZcIiBhbHQ9XCJBdmF0YXJcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXRpZ2h0XCI+e3NlbGVjdGVkQWNjb3VudE5hbWUucmVwbGFjZSgvXFxzKy9nLCAnJykudG9Mb3dlckNhc2UoKX08L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG9wYWNpdHktNjBcIj5TcG9uc29yZWQ8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMSBoLTEgYmctYmxhY2sgZGFyazpiZy13aGl0ZSByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMSBoLTEgYmctYmxhY2sgZGFyazpiZy13aGl0ZSByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMSBoLTEgYmctYmxhY2sgZGFyazpiZy13aGl0ZSByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEltYWdlbiBJRyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGFzcGVjdC1zcXVhcmUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtOTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWhpZGRlbiBib3JkZXIteSBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByZWxhdGl2ZSBncm91cFwiPlxuICAgICAgICAgICAgICB7aW1hZ2VQcmV2aWV3ID8gKFxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtpbWFnZVByZXZpZXd9IGFsdD1cIlByZXZpZXdcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPEltYWdlIHNpemU9ezQ4fSBjbGFzc05hbWU9XCJvcGFjaXR5LTUwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5SZXF1aWVyZSBpbWFnZW4gb2JsaWdhdG9yaWE8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIHsvKiBQYWdpbmF0aW9uIERvdHMgZmFsc29zICovfVxuICAgICAgICAgICAgICB7aW1hZ2VQcmV2aWV3ICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS00IGZsZXggZ2FwLTEuNSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctd2hpdGUvNTBcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLXdoaXRlLzUwXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEFjdGlvbnMgSUcgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHQtMyBwYi0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgaXRlbXMtY2VudGVyIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgPEhlYXJ0IHNpemU9ezI0fSBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LXJlZC01MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIiAvPlxuICAgICAgICAgICAgICAgIDxNZXNzYWdlQ2lyY2xlIHNpemU9ezI0fSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiIC8+XG4gICAgICAgICAgICAgICAgPFNoYXJlMiBzaXplPXsyNH0gY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgLXJvdGF0ZS00NSBtYi0xXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxCb29rbWFyayBzaXplPXsyNH0gY2xhc3NOYW1lPVwidGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgY3Vyc29yLXBvaW50ZXJcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUZXh0byBJRyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMyBwYi00XCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi0xXCI+MSwzNDIgTWUgZ3VzdGE8L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIG1yLTJcIj57c2VsZWN0ZWRBY2NvdW50TmFtZS5yZXBsYWNlKC9cXHMrL2csICcnKS50b0xvd2VyQ2FzZSgpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7Y29udGVudCA/IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIndoaXRlc3BhY2UtcHJlLXdyYXBcIj57Y29udGVudH08L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGl0YWxpYyBmb250LW5vcm1hbFwiPkxhIGRlc2NyaXBjacOzbiBkZSB0dSBmb3RvIGFwYXJlY2Vyw6EgYXF1w60uLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBtdC0yIGZvbnQtbWVkaXVtIHRyYWNraW5nLXdpZGVyXCI+SGFjZSAyIGhvcmFzPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==