import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/AppLayout.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=03b8b458";
import { Outlet, Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=03b8b458";
import { LayoutDashboard, Calendar, PenTool, Settings, Bell, Zap, Sparkles, Menu, X, LogOut, CreditCard, Shield } from "/node_modules/.vite/deps/lucide-react.js?v=03b8b458";
import { useAuth } from "/src/contexts/AuthContext.tsx";
var _jsxFileName = "C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AppLayout.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=03b8b458";
var _s = $RefreshSig$();
export const AppLayout = () => {
	_s();
	const location = useLocation();
	const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
	const { user } = useAuth();
	const navItems = [
		{
			path: "/",
			icon: /* @__PURE__ */ _jsxDEV(LayoutDashboard, { size: 20 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 24
			}, this),
			label: "Dashboard"
		},
		{
			path: "/calendar",
			icon: /* @__PURE__ */ _jsxDEV(Calendar, { size: 20 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 32
			}, this),
			label: "Calendario"
		},
		{
			path: "/compose",
			icon: /* @__PURE__ */ _jsxDEV(PenTool, { size: 20 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 31
			}, this),
			label: "Crear Post"
		},
		{
			path: "/campaigns",
			icon: /* @__PURE__ */ _jsxDEV(Zap, { size: 20 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 33
			}, this),
			label: "Piloto IA"
		},
		{
			path: "/billing",
			icon: /* @__PURE__ */ _jsxDEV(CreditCard, { size: 20 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 31
			}, this),
			label: "Suscripción"
		},
		{
			path: "/settings",
			icon: /* @__PURE__ */ _jsxDEV(Settings, { size: 20 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 32
			}, this),
			label: "Configuración"
		}
	];
	if (user?.role === "SUPERADMIN") {
		navItems.push({
			path: "/superadmin",
			icon: /* @__PURE__ */ _jsxDEV(Shield, { size: 20 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 48
			}, this),
			label: "Admin SaaS"
		});
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex h-screen bg-transparent transition-colors duration-500 overflow-hidden relative",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-brand-400/20 dark:bg-brand-600/10 blur-[120px] pointer-events-none animate-float" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-purple-400/20 dark:bg-purple-600/10 blur-[120px] pointer-events-none animate-float",
				style: { animationDelay: "2s" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this),
			isMobileMenuOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 md:hidden",
				onClick: () => setIsMobileMenuOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("aside", {
				className: `fixed md:relative top-0 left-0 h-full w-72 glass-panel flex flex-col md:m-4 md:mr-2 md:rounded-2xl shadow-xl shadow-brand-500/5 z-50 border border-white/40 dark:border-slate-700/50 transition-transform duration-300 ease-in-out ${isMobileMenuOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-6 flex items-center justify-between border-b border-slate-200/50 dark:border-slate-700/50",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 shadow-lg shadow-brand-500/30 flex items-center justify-center text-white font-bold text-xl relative overflow-hidden group",
							children: [/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-in-out" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Sparkles, {
								size: 20,
								className: "relative z-10"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-slate-500 dark:from-white dark:to-slate-300 tracking-tight",
							children: "Smart Publish"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "md:hidden text-slate-500 hover:text-brand-500",
						onClick: () => setIsMobileMenuOpen(false),
						children: /* @__PURE__ */ _jsxDEV(X, { size: 24 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("nav", {
					className: "flex-1 p-4 space-y-2 overflow-y-auto",
					children: navItems.map((item) => {
						const isActive = location.pathname === item.path;
						return /* @__PURE__ */ _jsxDEV(Link, {
							to: item.path,
							onClick: () => setIsMobileMenuOpen(false),
							className: `group flex items-center gap-3 px-4 py-3.5 rounded-xl font-medium transition-all duration-300 relative overflow-hidden ${isActive ? "text-brand-700 dark:text-brand-300 shadow-sm" : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"}`,
							children: [
								isActive && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-r from-brand-100 to-brand-50/50 dark:from-brand-900/40 dark:to-brand-800/20 border border-brand-200 dark:border-brand-800/50 rounded-xl -z-10" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 19
								}, this),
								!isActive && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-slate-100 dark:bg-slate-800/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl -z-10" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 80,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: `transition-transform duration-300 ${isActive ? "scale-110 text-brand-500 dark:text-brand-400" : "group-hover:scale-110 group-hover:text-brand-500 dark:group-hover:text-brand-400"}`,
									children: item.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 82,
									columnNumber: 17
								}, this),
								item.label
							]
						}, item.path, true, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col h-full overflow-hidden md:m-4 md:ml-2 glass-panel md:rounded-2xl shadow-xl shadow-slate-200/10 dark:shadow-none z-10 border-0 md:border border-white/40 dark:border-slate-700/50",
				children: [/* @__PURE__ */ _jsxDEV("header", {
					className: "h-[72px] border-b border-slate-200/50 dark:border-slate-700/50 flex items-center justify-between px-4 md:px-8 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-4 flex-1",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "md:hidden p-2 text-slate-500 hover:text-brand-500",
							onClick: () => setIsMobileMenuOpen(true),
							children: /* @__PURE__ */ _jsxDEV(Menu, { size: 24 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-sm font-medium text-slate-500 dark:text-slate-400 capitalize hidden sm:block",
							children: location.pathname === "/" ? "Dashboard" : location.pathname.replace("/", "")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 md:gap-4",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								className: "relative p-2.5 text-slate-400 hover:text-brand-500 transition-all rounded-xl hover:bg-white dark:hover:bg-slate-800 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 hover:shadow-sm",
								children: [/* @__PURE__ */ _jsxDEV(Bell, { size: 20 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { className: "absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#1e293b] dark:border-slate-900 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 pl-2 md:pl-4 border-l border-slate-200 dark:border-slate-700/50 cursor-pointer group",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-right hidden sm:block",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-bold text-slate-700 dark:text-slate-200 leading-tight group-hover:text-brand-500 transition-colors",
										children: "Admin Usuario"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-500 font-medium",
										children: "Plan Pro"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 115,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-500 to-brand-400 flex items-center justify-center text-white shadow-md shadow-brand-500/20 group-hover:scale-105 transition-transform overflow-hidden",
									children: /* @__PURE__ */ _jsxDEV("img", {
										src: "https://ui-avatars.com/api/?name=Admin&background=0ea5e9&color=fff&bold=true",
										alt: "Avatar",
										className: "w-full h-full object-cover"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 118,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									localStorage.removeItem("auth_token");
									localStorage.removeItem("auth_user");
									window.location.href = "/login";
								},
								className: "ml-2 p-2.5 text-slate-400 hover:text-red-500 transition-colors rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 border border-transparent hover:border-red-100 dark:hover:border-red-900/30",
								title: "Cerrar Sesión",
								children: /* @__PURE__ */ _jsxDEV(LogOut, { size: 20 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 overflow-x-hidden overflow-y-auto p-4 md:p-8 relative",
					children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
};
_s(AppLayout, "yI5a6dQOaZ2ZOvarUIFYNPJAFuk=", false, function() {
	return [useLocation, useAuth];
});
_c = AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/AppLayout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AppLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AppLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Admin/Desktop/smart-publish/frontend/src/components/layout/AppLayout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxRQUFRLE1BQU0sbUJBQW1CO0FBQzFDLFNBQVMsaUJBQWlCLFVBQVUsU0FBUyxVQUFVLE1BQU0sS0FBSyxVQUFVLE1BQU0sR0FBRyxRQUFRLFlBQVksY0FBYztBQUN2SCxTQUFTLGVBQWU7Ozs7QUFFeEIsT0FBTyxNQUFNLGtCQUFrQjs7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxLQUFLO0NBQzlELE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FFekIsTUFBTSxXQUFXO0VBQ2Y7R0FBRSxNQUFNO0dBQUssTUFBTSx3QkFBQyxpQkFBRCxFQUFpQixNQUFNLEdBQUs7Ozs7O0dBQUcsT0FBTztFQUFZO0VBQ3JFO0dBQUUsTUFBTTtHQUFhLE1BQU0sd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7Ozs7R0FBRyxPQUFPO0VBQWE7RUFDdkU7R0FBRSxNQUFNO0dBQVksTUFBTSx3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7OztHQUFHLE9BQU87RUFBYTtFQUNyRTtHQUFFLE1BQU07R0FBYyxNQUFNLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O0dBQUcsT0FBTztFQUFZO0VBQ2xFO0dBQUUsTUFBTTtHQUFZLE1BQU0sd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7Ozs7R0FBRyxPQUFPO0VBQWM7RUFDekU7R0FBRSxNQUFNO0dBQWEsTUFBTSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztHQUFHLE9BQU87RUFBZ0I7Q0FDNUU7Q0FFQSxJQUFJLE1BQU0sU0FBUyxjQUFjO0VBQy9CLFNBQVMsS0FBSztHQUFFLE1BQU07R0FBZSxNQUFNLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O0dBQUcsT0FBTztFQUFhLENBQUM7Q0FDeEY7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFELEVBQUssV0FBVSxtSkFBb0o7Ozs7O0dBQ25LLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQXlKLE9BQU8sRUFBRSxnQkFBZ0IsS0FBSztHQUFJOzs7OztHQUd6TSxvQkFDQyx3QkFBQyxPQUFEO0lBQ0UsV0FBVTtJQUNWLGVBQWUsb0JBQW9CLEtBQUs7R0FDekM7Ozs7O0dBSUgsd0JBQUMsU0FBRDtJQUNFLFdBQVcsc09BQ1QsbUJBQW1CLGtCQUFrQjtjQUZ6QyxDQUtFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsd0hBQXlIOzs7O2lCQUN4SSx3QkFBQyxVQUFEO1FBQVUsTUFBTTtRQUFJLFdBQVU7T0FBaUI7Ozs7ZUFDNUM7Ozs7O2dCQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFnSjtNQUUxSjs7OztjQUNEOzs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxXQUFVO01BQ1YsZUFBZSxvQkFBb0IsS0FBSztnQkFFeEMsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7S0FDUjs7OzthQUNMOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osU0FBUyxLQUFLLFNBQVM7TUFDdEIsTUFBTSxXQUFXLFNBQVMsYUFBYSxLQUFLO01BQzVDLE9BQ0Usd0JBQUMsTUFBRDtPQUVFLElBQUksS0FBSztPQUNULGVBQWUsb0JBQW9CLEtBQUs7T0FDeEMsV0FBVyx5SEFDVCxXQUNJLGlEQUNBO2lCQVBSO1FBVUcsWUFDQyx3QkFBQyxPQUFELEVBQUssV0FBVSxnTEFBaUw7Ozs7O1FBRWpNLENBQUMsWUFDQSx3QkFBQyxPQUFELEVBQUssV0FBVSx3SUFBeUk7Ozs7O1FBRTFKLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLHFDQUFxQyxXQUFXLGlEQUFpRDttQkFDOUcsS0FBSztRQUNIOzs7OztRQUNKLEtBQUs7T0FDRjtTQW5CQyxLQUFLOzs7O2FBbUJOO0tBRVYsQ0FBQztJQUNFOzs7O1lBQ0E7Ozs7OztHQUdQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtlQUFsQixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLFdBQVU7T0FDVixlQUFlLG9CQUFvQixJQUFJO2lCQUV2Qyx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztNQUNYOzs7O2dCQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFNBQVMsYUFBYSxNQUFNLGNBQWMsU0FBUyxTQUFTLFFBQVEsS0FBSyxFQUFFO01BQ3pFOzs7O2NBQ0Y7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtrQkFBbEIsQ0FDRSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2tCQUNqQix3QkFBQyxRQUFELEVBQU0sV0FBVSwySEFBaUk7Ozs7Z0JBQzNJOzs7Ozs7T0FDUix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWtIO1NBQWdCOzs7O21CQUMvSSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBcUM7U0FBVzs7OztpQkFDMUQ7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE9BQUQ7VUFBSyxLQUFJO1VBQStFLEtBQUk7VUFBUyxXQUFVO1NBQThCOzs7OztRQUMxSTs7OztnQkFDRjs7Ozs7O09BQ0wsd0JBQUMsVUFBRDtRQUNFLGVBQWU7U0FDYixhQUFhLFdBQVcsWUFBWTtTQUNwQyxhQUFhLFdBQVcsV0FBVztTQUNuQyxPQUFPLFNBQVMsT0FBTztRQUN6QjtRQUNBLFdBQVU7UUFDVixPQUFNO2tCQUVOLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O09BQ2I7Ozs7O01BQ0w7Ozs7O2FBQ0M7Ozs7O2NBR1Isd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDZCx3QkFBQyxRQUFELENBQVM7Ozs7O0lBQ0w7Ozs7WUFDSDs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcExheW91dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBPdXRsZXQsIExpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBMYXlvdXREYXNoYm9hcmQsIENhbGVuZGFyLCBQZW5Ub29sLCBTZXR0aW5ncywgQmVsbCwgWmFwLCBTcGFya2xlcywgTWVudSwgWCwgTG9nT3V0LCBDcmVkaXRDYXJkLCBTaGllbGQgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0JztcblxuZXhwb3J0IGNvbnN0IEFwcExheW91dCA9ICgpID0+IHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICBjb25zdCBbaXNNb2JpbGVNZW51T3Blbiwgc2V0SXNNb2JpbGVNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xuXG4gIGNvbnN0IG5hdkl0ZW1zID0gW1xuICAgIHsgcGF0aDogJy8nLCBpY29uOiA8TGF5b3V0RGFzaGJvYXJkIHNpemU9ezIwfSAvPiwgbGFiZWw6ICdEYXNoYm9hcmQnIH0sXG4gICAgeyBwYXRoOiAnL2NhbGVuZGFyJywgaWNvbjogPENhbGVuZGFyIHNpemU9ezIwfSAvPiwgbGFiZWw6ICdDYWxlbmRhcmlvJyB9LFxuICAgIHsgcGF0aDogJy9jb21wb3NlJywgaWNvbjogPFBlblRvb2wgc2l6ZT17MjB9IC8+LCBsYWJlbDogJ0NyZWFyIFBvc3QnIH0sXG4gICAgeyBwYXRoOiAnL2NhbXBhaWducycsIGljb246IDxaYXAgc2l6ZT17MjB9IC8+LCBsYWJlbDogJ1BpbG90byBJQScgfSxcbiAgICB7IHBhdGg6ICcvYmlsbGluZycsIGljb246IDxDcmVkaXRDYXJkIHNpemU9ezIwfSAvPiwgbGFiZWw6ICdTdXNjcmlwY2nDs24nIH0sXG4gICAgeyBwYXRoOiAnL3NldHRpbmdzJywgaWNvbjogPFNldHRpbmdzIHNpemU9ezIwfSAvPiwgbGFiZWw6ICdDb25maWd1cmFjacOzbicgfSxcbiAgXTtcblxuICBpZiAodXNlcj8ucm9sZSA9PT0gJ1NVUEVSQURNSU4nKSB7XG4gICAgbmF2SXRlbXMucHVzaCh7IHBhdGg6ICcvc3VwZXJhZG1pbicsIGljb246IDxTaGllbGQgc2l6ZT17MjB9IC8+LCBsYWJlbDogJ0FkbWluIFNhYVMnIH0pO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1zY3JlZW4gYmctdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tNTAwIG92ZXJmbG93LWhpZGRlbiByZWxhdGl2ZVwiPlxuICAgICAgey8qIEFuaW1hdGVkIEJhY2tncm91bmQgT3JicyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLVstMTAlXSBsZWZ0LVstMTAlXSB3LVs0MCVdIGgtWzQwJV0gcm91bmRlZC1mdWxsIGJnLWJyYW5kLTQwMC8yMCBkYXJrOmJnLWJyYW5kLTYwMC8xMCBibHVyLVsxMjBweF0gcG9pbnRlci1ldmVudHMtbm9uZSBhbmltYXRlLWZsb2F0XCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLVstMTAlXSByaWdodC1bLTEwJV0gdy1bNDAlXSBoLVs0MCVdIHJvdW5kZWQtZnVsbCBiZy1wdXJwbGUtNDAwLzIwIGRhcms6YmctcHVycGxlLTYwMC8xMCBibHVyLVsxMjBweF0gcG9pbnRlci1ldmVudHMtbm9uZSBhbmltYXRlLWZsb2F0XCIgc3R5bGU9e3sgYW5pbWF0aW9uRGVsYXk6ICcycycgfX0gLz5cblxuICAgICAgey8qIE92ZXJsYXkgcGFyYSBtw7N2aWxlcyAqL31cbiAgICAgIHtpc01vYmlsZU1lbnVPcGVuICYmIChcbiAgICAgICAgPGRpdiBcbiAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLXNsYXRlLTkwMC81MCBiYWNrZHJvcC1ibHVyLXNtIHotNDAgbWQ6aGlkZGVuXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc01vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBTaWRlYmFyICovfVxuICAgICAgPGFzaWRlIFxuICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCBtZDpyZWxhdGl2ZSB0b3AtMCBsZWZ0LTAgaC1mdWxsIHctNzIgZ2xhc3MtcGFuZWwgZmxleCBmbGV4LWNvbCBtZDptLTQgbWQ6bXItMiBtZDpyb3VuZGVkLTJ4bCBzaGFkb3cteGwgc2hhZG93LWJyYW5kLTUwMC81IHotNTAgYm9yZGVyIGJvcmRlci13aGl0ZS80MCBkYXJrOmJvcmRlci1zbGF0ZS03MDAvNTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0ICR7XG4gICAgICAgICAgaXNNb2JpbGVNZW51T3BlbiA/ICd0cmFuc2xhdGUteC0wJyA6ICctdHJhbnNsYXRlLXgtZnVsbCBtZDp0cmFuc2xhdGUteC0wJ1xuICAgICAgICB9YH1cbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAvNTAgZGFyazpib3JkZXItc2xhdGUtNzAwLzUwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLWJyYW5kLTQwMCB0by1icmFuZC02MDAgc2hhZG93LWxnIHNoYWRvdy1icmFuZC01MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXdoaXRlLzIwIHRyYW5zbGF0ZS15LWZ1bGwgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXktMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXRcIiAvPlxuICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MjB9IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNsYXRlLTgwMCB0by1zbGF0ZS01MDAgZGFyazpmcm9tLXdoaXRlIGRhcms6dG8tc2xhdGUtMzAwIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgIFNtYXJ0IFB1Ymxpc2hcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1kOmhpZGRlbiB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMFwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc01vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBzaXplPXsyNH0gLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImZsZXgtMSBwLTQgc3BhY2UteS0yIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgIHtuYXZJdGVtcy5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gbG9jYXRpb24ucGF0aG5hbWUgPT09IGl0ZW0ucGF0aDtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAga2V5PXtpdGVtLnBhdGh9XG4gICAgICAgICAgICAgICAgdG89e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc01vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bncm91cCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTMuNSByb3VuZGVkLXhsIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gJHtcbiAgICAgICAgICAgICAgICAgIGlzQWN0aXZlIFxuICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LWJyYW5kLTcwMCBkYXJrOnRleHQtYnJhbmQtMzAwIHNoYWRvdy1zbScgXG4gICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtpc0FjdGl2ZSAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJyYW5kLTEwMCB0by1icmFuZC01MC81MCBkYXJrOmZyb20tYnJhbmQtOTAwLzQwIGRhcms6dG8tYnJhbmQtODAwLzIwIGJvcmRlciBib3JkZXItYnJhbmQtMjAwIGRhcms6Ym9yZGVyLWJyYW5kLTgwMC81MCByb3VuZGVkLXhsIC16LTEwXCIgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIHshaXNBY3RpdmUgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMC81MCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMCByb3VuZGVkLXhsIC16LTEwXCIgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwICR7aXNBY3RpdmUgPyAnc2NhbGUtMTEwIHRleHQtYnJhbmQtNTAwIGRhcms6dGV4dC1icmFuZC00MDAnIDogJ2dyb3VwLWhvdmVyOnNjYWxlLTExMCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOmdyb3VwLWhvdmVyOnRleHQtYnJhbmQtNDAwJ31gfT5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLmljb259XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvbmF2PlxuICAgICAgPC9hc2lkZT5cblxuICAgICAgey8qIE1haW4gQ29udGVudCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiBtZDptLTQgbWQ6bWwtMiBnbGFzcy1wYW5lbCBtZDpyb3VuZGVkLTJ4bCBzaGFkb3cteGwgc2hhZG93LXNsYXRlLTIwMC8xMCBkYXJrOnNoYWRvdy1ub25lIHotMTAgYm9yZGVyLTAgbWQ6Ym9yZGVyIGJvcmRlci13aGl0ZS80MCBkYXJrOmJvcmRlci1zbGF0ZS03MDAvNTBcIj5cbiAgICAgICAgey8qIFRvcGJhciAqL31cbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJoLVs3MnB4XSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwLzUwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMC81MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNCBtZDpweC04IGJnLXdoaXRlLzQwIGRhcms6Ymctc2xhdGUtOTAwLzQwIGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IGZsZXgtMVwiPlxuICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWQ6aGlkZGVuIHAtMiB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMFwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzTW9iaWxlTWVudU9wZW4odHJ1ZSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxNZW51IHNpemU9ezI0fSAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBjYXBpdGFsaXplIGhpZGRlbiBzbTpibG9ja1wiPlxuICAgICAgICAgICAgICB7bG9jYXRpb24ucGF0aG5hbWUgPT09ICcvJyA/ICdEYXNoYm9hcmQnIDogbG9jYXRpb24ucGF0aG5hbWUucmVwbGFjZSgnLycsICcnKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWQ6Z2FwLTRcIj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicmVsYXRpdmUgcC0yLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1icmFuZC01MDAgdHJhbnNpdGlvbi1hbGwgcm91bmRlZC14bCBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1zbGF0ZS0yMDAgZGFyazpob3Zlcjpib3JkZXItc2xhdGUtNzAwIGhvdmVyOnNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICA8QmVsbCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgcmlnaHQtMiB3LTIuNSBoLTIuNSBiZy1yZWQtNTAwIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItWyMxZTI5M2JdIGRhcms6Ym9yZGVyLXNsYXRlLTkwMCBhbmltYXRlLXB1bHNlXCI+PC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHBsLTIgbWQ6cGwtNCBib3JkZXItbCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMC81MCBjdXJzb3ItcG9pbnRlciBncm91cFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHQgaGlkZGVuIHNtOmJsb2NrXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBsZWFkaW5nLXRpZ2h0IGdyb3VwLWhvdmVyOnRleHQtYnJhbmQtNTAwIHRyYW5zaXRpb24tY29sb3JzXCI+QWRtaW4gVXN1YXJpbzwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtXCI+UGxhbiBQcm88L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXRyIGZyb20tYnJhbmQtNTAwIHRvLWJyYW5kLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzaGFkb3ctYnJhbmQtNTAwLzIwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8aW1nIHNyYz1cImh0dHBzOi8vdWktYXZhdGFycy5jb20vYXBpLz9uYW1lPUFkbWluJmJhY2tncm91bmQ9MGVhNWU5JmNvbG9yPWZmZiZib2xkPXRydWVcIiBhbHQ9XCJBdmF0YXJcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2F1dGhfdG9rZW4nKTtcbiAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYXV0aF91c2VyJyk7XG4gICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSAnL2xvZ2luJztcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiBwLTIuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJlZC01MDAgdHJhbnNpdGlvbi1jb2xvcnMgcm91bmRlZC14bCBob3ZlcjpiZy1yZWQtNTAgZGFyazpob3ZlcjpiZy1yZWQtOTAwLzIwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLXJlZC0xMDAgZGFyazpob3Zlcjpib3JkZXItcmVkLTkwMC8zMFwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiQ2VycmFyIFNlc2nDs25cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8TG9nT3V0IHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvaGVhZGVyPlxuXG4gICAgICAgIHsvKiBEeW5hbWljIFJvdXRlIENvbnRlbnQgKi99XG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy14LWhpZGRlbiBvdmVyZmxvdy15LWF1dG8gcC00IG1kOnAtOCByZWxhdGl2ZVwiPlxuICAgICAgICAgIDxPdXRsZXQgLz5cbiAgICAgICAgPC9tYWluPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19